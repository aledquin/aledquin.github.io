Copyright 2018 Synopsys, Inc.
This Synopsys IP and all associated documentation are proprietary to
Synopsys, Inc. and may only be used pursuant to the terms and conditions
of a written license agreement with Synopsys, Inc. All other use,
reproduction, modification, or distribution of the Synopsys IP or the
associated documentation is strictly prohibited.
------------------------------------------------------------------
LPDDR4_MULTIPHY_V2 FIRMWARE

Version A-2018.10-DDR3L
30-Apr-2019

Changes from version A-2018.10

This version only contains support for DDR3/DDR3L. All other protocols have been removed.
This is version is to be used with the dwc_ap_lpddr4x_multiphy_tsmc16ffc18 to augment
LPDDR4X, LPDDR4, and DDR4

------------------------------------------------------------------
Version A-2018.10
October 5, 2018

==========================================
Training Firmware A-2018.10 Release Notes:
==========================================

Changes from version A-2018.05
(recommended)

Improvements
------------


[1] LP4 Quick2D stage now measures RdDBI at the same time as the DQ, similarly to the Rx2D update.

[2] LP4 now writes MR14 before CA training begins.

[3] LP4 byte=swizzle detection done before CA training had it's ACSM sequence optimized.
 + Now sends less DES commands

[4] CaVref Training is deprecated.

Unsupported Features
---------------------
The following features are NOT supported:
  - LPDDR2 protocol is not supported
  - ACX8 configuration is not supported

Firmware and/or RTL includes code of unsupported features that do not affect the operation of supported features. 
The PHY has been simulation regressed to ensure the supported features are not impacted by the inclusion of these unsupported features. 
The unsupported features must not be used and Synopsys will not address queries related to these unsupported features.


Minimum Required Versions
-------------------------
- PUB: 1.00a
- Phyinit: A-2018.10

=====================================
ATE FIRMWARE A-2018.10 Release Notes:
=====================================

Changes from version A-2018.05
(required)

[1]  Added the CalVrefs CSR to the list of CSRs that may need to get written before ATE firmware is run for some low power LPDDR4 uses.
     This is for STAR 9001339965.
[2]  Fixed an error in the PLL lock test that was not checking the correct instances for LCDLs for the AC6 and AC3 configurations.
[3]  Updated the wording for the MinPadLpbkPwr message block setting to indicate that it will save some power for core loopback.
[4]  Updated the values used by the ATE firmware for DllLockParam and DllGainCtl to account for new circuit data.
[5]  Updated the configuration of the PLL during the lock test to improve lock detection. This is for STAR 9001359622.
[6]  Added an additional check to the PLL lock test that will make sure all the LCDLs lock within an expected range. If any LCDL locks 
     outside this range, the PLL lock test will be marked as failing.
[7]  Fixed an error in the LCDL linearity test where the results for the RxClk LCDLs where being put in the wrong message block locations.
     The rxclk[0/1]t results were being put in the rxclk[0/1]c message block fields and vice versa. This is for STAR 9001362154.
[8]  Added note to indicate that setting the DatLoop1dminEyeWidth too low can result in incorrect test results.
[9] Updated the recommended values for setting DqDqsRcvCntrl to use the same termination determined settings for both core and pad
     loopback.

------------------------------------------------------------------


Version A-2018.05
May 4, 2018

==========================================
Training Firmware A-2018.05 Release Notes:
==========================================

Changes from version A-2017.11
(recommended)

Improvements
------------

[1] Improved read deskew accuracy across various corner cases.

[2] Share2DVref behavior no longer makes assumptions about what order the phyinit sequence will run 1D and 2D training.


Minimum Required Versions
-------------------------
- PUB: 1.00a
- Phyinit: A-2018.05

=====================================
ATE FIRMWARE A-2018.05 Release Notes:
=====================================

Changes from version A-2017.11
(required)

[1] Removed Synopsys internal only LCDL offset test from the binary to reduce code size.

[2] Adjusted the LCDL Linearity test to run the ring oscillators once at the beginning of the test to clear out any unknowns 
    for STAR #9001300321 (Timing violation during ATE LCDL linearity test).

[3] Adjusted the LCDL Linearity test to use the user specified LcdlStartPhase as the initial point for the linear line for comparisons rather
    than using a static phase 0 value. This allows users affected by STAR #9001300321 (Timing violation during ATE LCDL linearity test) to skip 
    testing the lowest phases if necessary. Users not affected by this STAR should specify 0 as the LcdlStartPhase value.

[4] Added TestOptions and Technology message block fields to allow for future use when needed. The only option that is currently in use is 
    TestOptions[2], which causes the firmware to turn off some of the power savings features. This field can be used to enable clocks to all
    Dbytes if a non-standard ACX4 instance is used to drive the clocks to the Dbytes.

[5] Removed the Synopsys internal only LCDL offset test from the binary image to reduce the size of the firmware load.

[6] Added support for non-standard 2 Dbyte configurations for the Data Loopback tests.

[7] Added a check to the Data Loopback tests for a data eye that is wider than possible (significantly larger than 1UI). Some customers with
    power issues where the digital logic was not operating correctly were getting pass indications. The problem was caught as part of ATPG testing
    but not by the ATE firmware.

[8] Adjusted the end of test register restoration for the PLL control registers to reset them to the value when the test was run rather than a fixed value.

[9] Fixed a potential failure condition in detecting non-functional error count logic during Data Loopback. This error would also be caught during ATPG.


------------------------------------------------------------------

Version A-2017.11
November 3, 2017

==========================================
Training Firmware A-2017.11 Release Notes:
==========================================

Changes from version A-2017.09
(recommended)


Improvements
------------

[1] Added firmware support for ARC SRAM ECC

+ The microcontroller's registers are now cleared at the start of training
+ Previously the uninitialized registers could cause X's to enter the DCCM, triggering ECC errors. 

[2] Added a new debug statement for visibility of interesting MRS settings.

Minimum Required Versions
-------------------------
- PUB: 1.00a
- Phyinit: A-2017.05

=====================================
ATE FIRMWARE A-2017.11 Release Notes:
=====================================

Changes from version A-2017.09
(recommended)

[1] Added the feature that allows BP_MEMRESET_L also to be used to indicate firmware done.

+ ATE firmware will now drive BP_MEMRESET_L low while firmware is running, and high when it finishes

[2] Fixed an error in the SDR AC loopback PRBS that could cause incorrect eye width measurements.

[3] The upper bit of the firmware now indicates a technology specific version. This bit will read 0 in the non-technology specific version (no change).

[4] Deprecated the PrbsSeed from the data loopback test message block inputs. The test now uses a fixed seed for the PRBS that was the default seed before.


------------------------------------------------------------------

Version A-2017.09
September 1, 2017

==========================================
Training Firmware A-2017.09 Release Notes:
==========================================

Changes from version A-2017.07
(recommended)


Special Notes
-------------
The A-2017.09 LPDDR3 firmware includes changes from A-2017.07 as well as A-2017.09
Please read the A-2017.07 release notes below for the additional LPDDR3 changes.


New Features 
------------

[1] Added firmware support for x8 lpddr4 devices. To enable, set X8Mode=0xF.

+ Mixed mode, or training a mixture of x8 and x16 devices connected to the same phy, is still unsupported. 
+ Refer to messageblock header for more details.

[2] Added firmware support for training pass/fail hardware interrupts.

+ Has no impact on pub/phy versions that do not support, or do not enable, hardware interrupts.

[3] Added bitTimeControl to 2D training, set through Reserved0E[0:3].
   
+ When non-zero, bitTimeControl increases the number of bits checked for errors in all 2D stages, 
  trading off run-time for improved accuracy.
+ Especially beneficial for noisier systems. 
+ Refer to messageblock header for more details.

[4] Added Exhaustive2D to 2D training. To enable, set Reserved0E[4]=1.

+ When enabled, Exhaustive2D changes 2D's optimization algorithm to evaluate 
  every point of the passing region, improving eye-centering at the cost of run-time 
+ Recommended when the desired eye centers are near the left or right edge of the passing region. 
  such as with asymmetric eyes, which have their best voltage margin near one edge of the eye.
+ Refer to messageblock header for more details.

[5] Added phy and device vref(DQ) range constraints.

+ To set a phy reference voltage range, write Reserved1A[0:3].     
  When non-zero, Rd2D will only search for passing regions +/- (2*Reserved1A[0:3]) %VDDQ from PhyVref. 
+ To set a Dram reference voltage range, write  Reserved1A[4:7]
  when non-zero, Wr2D will only search for passing regions +/- (2*Reserved1A[4:7]) %VDDQ from MR14.  
+ Reduces 2D training time by constraining data collection to only the voltage settings a customers deems important. 
+ Setting a range constraint that's significantly larger than necessary may increase 2D training time by forcing
  data collection to run at many completely failing voltages that 2D would normally optimize out. 
+ Refer to messageblock header for more details.
   
[6] Added quickRd2D, a substage of read deskew, to 1D training. To enable, set Reserved00[5]=1

+ When enabled, quickRd2D will run just before read deskew, using the same simple patterns as deskew
  to train the phy's per-lane reference voltages in around 500 microseconds. 
+ QuickRd2D must be set when training systems where one reference voltage setting, phyVref, will not work
  for all receivers. Otherwise quick2D is largely unnecessary, especially if running 2D training. 
+ Read deskew must be enabled in sequenceCtrl for quickRd2D to run. Like read deskew, quickRd2D should only be run in pstate0.
+ Refer to messageblock header for more details.


Improvements
------------

[1] Updated coarse write leveling to increase maximum trainable frequency from 3733MT/s to 4267 MT/s 

Minimum Required Versions
-------------------------
- PUB: 1.00a
- Phyinit: A-2017.05

=====================================
ATE FIRMWARE A-2017.09 Release Notes:
=====================================

No Changes from version A-2017.07

------------------------------------------------------------------

Version vA-2017.07
July 7, 2017 

==========================================
Training Firmware A-2017.07 Release Notes:
==========================================

Changes from version A-2017.05
(recommended)

Special Notes
-------------
The LPDDR3 firmware image is unchanged from A-2017.05. The below changes do not apply to lpddr3. 


New Features 
------------
[1] Added High-Effort WrDQ1D. To enable, set Reserved00[6] = 1.  

+ When enabled, High-Effort WrDq1D modifies the standard WrDq1D training step, allowing WrDq1D to iterate 
  up to 4 times at different read-timings, to automatically recover from asymmetric read-eye collapse.
+ asymmetric eye collapse is when channel noise, like crosstalk, causes the passing region for complex patterns 
  to be significantly offset from the center of the passing region for simpler patterns. Normal WrDq1D is vulnerable to 
  asymmetric eye collapse because it relies on SI-friendly RdDqs1D's MPR patterns to train the
  read-timings that WrDq1D's PRBS pattern will use. 

[2] Added beta of HDTCTRL==4 debug messages.
+ HDTCTRL==4 allows the training firmware to send many more messages than could fit in the message-buffer
  by disabling message buffering and just sending messages during training. 
+ This mode should only be used for debug as the message handshake response times may extend training 
  time from a few milliseconds to several seconds. 
 

Improvements
------------

[1] Updated debug strings for all dram protocols to improve message clarity and consistency

+ Data Lanes are more consistently identified by Dbyte number and DQ number
+ Ranks are more consistently identified by the format {CS0,CS1,CS2,CS3}
+ Assertions messages in 1D read and 1D write will report zero width eyes as zero (instead of negative).
+ maxRdLat results are now printed in the table-format used by other stages. 
+ Other Miscellaneous wording improvements.

[2] HDTCTRL==5 debug messages will now include results from read deskew training
 
[3] HDTCTRL==5 debug messages will now include results from max read latency training
 
[4] HDTCTRL==5 debug messages will now include CA Training eye bitmaps

[5] [DisableBootClock debug mode] CA training enter wait time increase.

+ Edits to avoid violation of tCAENT when in debug-only Disable Boot Clock Mode and freq>DDR3200. 


Documentation Changes
---------------------
 
[1] Updated incorrect comment for messageblock field BPZNResVal 
+ Previous messageblock comment listed incorrect values for overriding the pre-programmed calibration resistors. 
  The messageblock comment now lists the correct values to enable override.

[2] Updated incorrect comment for messageblock field Reserved00[7]
+ Previous messageblock comment suggested Reserved00[7] only needed to be set when training DDR4 devices 
  with a TSMC28 phy. However, Reserved00[7] should be set any time a phy manufactured in TSMC28 is being trained.
 

Minimum Required Versions
-------------------------
- PUB: 1.00a
- Phyinit: A-2017.05

=====================================
ATE FIRMWARE A-2017.07 Release Notes:
=====================================

Changes from version A-2017.05
(recommended)

Enhancements
------------
+ Updated the revision numbering scheme in the ATE firmware to correspond to the
  release number. The AteImemRevision and AteDmemRevision values will now be coded
  as <YYYY><MM><RR> where YYYY is 4 digit year, MM is 2 digit month, and RR is two
  digit revision. YYYY and MM will be encoded as BCD, RR will be coded as an
  incrementing number from 0 to 255.
+ Added the ability to mask out errors on ACX4 pins if desired. This added 
  AcLoopLaneMask_MM_NN fields to the message block. MM and NN indicate which
  ACX4 instance the field masks. The bits represent the lanes of each ACX4 instance.
  If a bit is 0, all errors will be treated as test failures for that lane. If a bit
  is 1, then all errors will be ignored for pass/fail results for that lane.
+ Enhanced the Data loopback test to ensure that the ACX4 pins do not toggle during
  the test, which reduces the power requirements during the test.
+ Added the pulsing of the ALERT pin during the Burn-In test as a heartbeat indication.
+ Update the ATE firmware to allow users to set the TxEqualizationMode and TxImpedanceCtrl
  registers individually to match their usage.
+ Updated version number comment line in the message block header file by
  replacing it with a C define that indicates the revision number instead.


Minimum Required Versions
-------------------------
- PUB: 1.00a
- Phyinit: A-2017.05

------------------------------------------------------------------

Version A-2017.05
May 22, 2017

Changes from version 1.00a
(mandatory)

Bug Fixes
---------
- In LPDDR4 training, same PU-CAL value is used for both CHA and CHB before issuing CAL start cmd
- Set DqsPreambleControl correctly in case of DDR4 training.
- LPDDR4 1D write training was limiting it's final txdqdly results to 2 bits of coarse delay, when the RTL supports 3 bits of coarse delay.

Enhancements
------------
- Read deskew enhancement provided a faster search algorithm by aligning min passing delays for each lane in a nibble


Minimum Required Versions
-------------------------
- PUB: 1.00a
- Phyinit: A-2017.05

------------------------------------------------------------------

Version 1.00a
Mar 31, 2017

Changes from version 0.73a
(mandatory)

Bug Fixes
---------
- ATE firmware update so Command and Address pins toggle at the expected rate
  during the Burn-In test.
- Training firmware drive strength calibration update in the case where
  the external resistor was not 240 ohm.
- ATE firmware was causing the PLL lock routine to wait longer than was necessary.
  This resulted in the lock test to take longer than expected.
- In LPDDR4 training, MRW commands being sent multiple times when passing control
  back the the memory controller.
Enhancements
------------
- Updated the default value for RxPBDly in the data loopback test improve
  accuracy in simulations where the IO delays are not being simulated (simulation only).
- Improved the LCDL lock time during the calibration for training.
- Enhanced the 2D training firmware to more accurately map especially
  noisy eye contours.
- Enhanced the training firmware to add support when connected to 5 x16 devices. 
  Since the PHY only has 9 Dbytes, it will not attempt to train the 
  unconnected lanes. Only applies to when half of x16 device is on DBYTE8.
  DBYTE0 through DBYTE8 must be on fully populated x16 devices.
- Enhanced the 2D training to not send commands to unpopulated ranks.
- Firmware enhanced with settings unique to TSMC28. To enable, set Reserved00[7] to 1 in the messageblock.


Minimum Required Versions
-------------------------
- PUB: 1.00a
- Phyinit: 2.00a

------------------------------------------------------------------

Version 0.73a
Feb 24, 2017

Changes from version 0.72a
(mandatory)

Bug Fixes
---------
- 2D training may have written incorrect values to some of the
  MRs during training.
- 2D training firmware may have seen a larger eye than was actually present under
  some corner conditions.
- ATE firmware may not have toggled the slow clock during the PLL lock test for the
  correct amount of time.
- LCDL linearity test may have caused a passing LCDL to overwrite
  a failing LCDL and report that the test passed.
- DDR3 for the 3 Dbyte configurations may have caused training to not complete
  successfully.
- For LPDDR4, corrected the output level of some debug messages that were being
  output at higher levels of HwtCtrl.
- For LPDDR4, the slow clock output may not have been within spec for lower speed of
  DfiClk. The correct amount of time may have been miscalculated during
  slow clock operations.
- For LPDDR4, the DQS oscillator may have overflowed the DRAM during training.


Enhancements
------------
- Changed the time base of the slow clock time for the PLL Lock Test in the ATE
  firmware from nanoseconds to microseconds to allow a greater range of values.
- Added the ability to run the ACX4 or Dbyte instance in serial for the ATE loopback
  tests to reduce the amount of power required during the test. This results in
  longer run time if this option is used.
- Addressed a simulation issue with some models that don't reset the MR values
  correctly after reset is asserted.
- Adjusted the training to add support for DDR4 MRAM.
- ATE Firmware will allow simulation to run loopback tests if either the
  Impedance Calibration or the PLL Lock tests failed.


Special Notes
-------------
This Firmware Image is not considered final and updates are to be expected.

Minimum Required Versions
-------------------------
- PUB: 1.00a
- Phyinit: 1.23a

------------------------------------------------------------------

Version 0.72a
Jan 26, 2017

Changes from version 0.71a
(mandatory)

Bug Fixes
---------
- ATE FW: LCDL Linearity testing improvements
- 2D FW: Update 2d DBI implementation
- Re-aligned wait time start to be after Dll Lock sequence begins
- Fix PDA mode in 2D training for partial-rank support
- Fixed tRCD violation in LPDDR4 and LPDDR3
- Use trained MR12 value in LP4 2D training

Enhancements
------------
- Reset fifo pointers when updating Max Read Latency.
- ATE FW: Add option to test each dbyte and anib loopback serially to reduce
  power
- ATE FW: Restore csrs to reset values at end of ATE
- Optimize Max Read Latency algorithm result to improve overall performance
- Allow override of PhyConfig Register if required by customer.  Feature is
  not fully supported.        
- Added DbyteDisable message block field.  Improve partial-dbyte support.
  Features are not fully supported.
  - Adjust swizzle to account for un-populated dbytes
- Update write leveling termination algorithm to address DRAM device vendor
  non-compliance to JEDEC spec.
- LPDDR4 Update dbyte detection algorithm (when WDQSEXTENSION is required) to
  address DRAM device vendor non-compliance to JEDEC spec 
- Improve preliminary LP4 tx dq training for coarse write leveling
- Improve delay reporting in LPDDR3,LPDDR4 for single channel configurations
- Enable Quickboot: restore of training csrs and reset in LPDDR4
- Improve training for single channel configurations
- LPDDR4: Add option to allow direct control of BP_MEMRESET_L via dfi_reset_n
  input

Special Notes
-------------
- ATE firmware has known issues with the following and therefore is not
  officially supported in this release
  * Firmware image may need to be reloaded between runs (if issues are seen in
    consecutive runs).
  * Tests may need to be run individually (if issues are seen running contiguously).
  * PLL Lock Test - slow clock mode may temporarily provide an incorrect output
    frequency for a short period of time when clock is externally driven by PHY.

This Firmware Image is not considered final and updates are to be expected.

Minimum Required Versions
-------------------------
- PUB: 1.00a
- Phyinit: 1.22a

------------------------------------------------------------------

Version 0.71a
December 1, 2016

Changes from version 0.70b
(mandatory)

Bug Fixes
---------
- Addressed Tx Vref calculation for LPDDR4.
- Addressed calculation of RxVref margin.
- Addressed a timing violation for LPDDR3 during training for writes to precharge.
- Addressed a parity error for SRE during DDDR4 training when parity is enabled.
- Addressed an issue in 2D training where the results were not showing a violation of the margin requirement.
- Addressed an issue where the MRL was being reset when DM training was enabled.
- Addressed issue with DDC post training in LPDDR4 that could lead to bubble violation.

Enhancements
------------
- Added a feature to perform CA training during the 2D training if requested
- Improvements to the 1D and 2D training algorithms due to silicon learning.
- Improvements to the DDR3/LPDDR3 write leveling algorithm.
- Improved DevInit procedure for LPDDR4.
- Changed LPDDR4 training to send MR24.
- Added ability to train CA Vref in LPDDR4.
- ATE firmware improvements.
- Improvements to the debug messages used by training firmware.
- General stability and code improvements.

Special Notes
-------------
- ATE firmware has known issues with the following and therefore is not
  officially supported in this release
  * Firmware image must be reloaded between runs
  * Tests must be run individually. 
  * These issues will be addressed in a subsequent release.
This Firmware Image is not considered final and updates are to be expected.

Minimum Required Versions
-------------------------
- PUB: 1.00a
- Phyinit: 1.20a

------------------------------------------------------------------

Version 0.70b
October 6, 2016

Changes from version 0.70a
(recommended)

Bug Fixes
---------
- Clarification from 0.70a Readme
  * csrDFIMRL no longer reset by 2D training when DDR4 DM enabled

Enhancements
------------
- None

Special Notes
-------------
- ATE firmware has known issues with the following tests and therefore
  are not supported in this release
  * AC Loopback
  * Data 1D/2D Loopback
  * Burn-in

Minimum Required Versions
-------------------------
- PUB: 1.00a
- Phyinit: 1.20a

------------------------------------------------------------------

Version 0.70a
Sep 16, 2016

Changes from version 0.61a
(mandatory)

Bug Fixes
---------
- csrDFIMRL no longer reset by 2D training

Enhancements
------------
- ATE firmware message block and interaction updated to be much closer to
  training firmware interaction.
- Update internal revision ID to match release.
- General product improvements in 1D and 2D training based on simulation and
  lab learnings.

Minimum Required Versions
-------------------------
- PUB: 1.00a
- Phyinit: 1.20a

------------------------------------------------------------------

Version 0.61a
Aug 15, 2016

Changes from version 0.60a
(recommended)

Bug Fixes
---------
- Improvements for customer enablement.
- Improvement to RxEnb training for large board delays
- Improvement to DM training
- Addressed training issue when Channel A not fully populated
- Addressed DDC issue for multiple power states.
- Improvements to CA training in LPDDR4
- Addressed training issue in LPDDR3 and LPDDR4 when DQ bits swizzled.

Enhancements
------------
- Firmware can disable all mailbox message, including errors

Special Notes
-------------
- Firmware improvements/enhancements ongoing. Updates to firmware should be expected.
  This is not a tapeout gating item.

Minimum Required Versions
-------------------------
- PUB: 1.00a
- Phyinit: 1.03a

------------------------------------------------------------------

Version 0.60a
Jul 22, 2016

Changes from version 0.51a
(recommended)

Bug Fixes
---------
- Addressed out-of-bound issue in LPDDR4 WrDq2D training.
- Addressed ANIB delay setting in LPDDR3/LPDDR4 CA training in case of CLK inversion.

Enhancements
------------
- 2D training switches between ranges in order to expand VDDQ range coverage

Special Notes
-------------
- Firmware improvements/enhancements ongoing. Updates to firmware should be expected.
  This is not a tapeout gating item.

Minimum Required Versions
-------------------------
- PUB: 1.00a
- Phyinit: 1.03a

------------------------------------------------------------------

Version 0.51a 
Jul 11, 2016

Changes from version 0.50a
(recommended)

Bug Fixes
---------
- Improvements for customer enablement.

Enhancements
------------
- Improvements for customer enablement.

Minimum Required Versions
-------------------------
- PUB: 1.00a
- Phyinit: 1.03a

------------------------------------------------------------------

Version 0.50a 
Jun 22, 2016

Changes from version 0.40a
(mandatory)

- Updated ATE firmware with improvements. ATE tests 3, 4, 5, 6, and 254 
  report errors in simulation on some configurations. The issue(s) will 
  be address in a future ATE release.
- Updated 1D firmware for LPDDR3, LPDDR4,DDR3 and DDR4, with improvements 
  and bug fixes.
- Updated 2D firmware for DDR4 and LPDDR4, with improvements and bug fixes.
- DDR3 message block updated to remove unused fields (marked as reserved).
- Improvements to documentation and comments related to firmware 
  message block.
- Bug fixes and improvements to the PhyInit process to enable the 
  training firmware.

Minimum Required Versions
-------------------------
- PUB: 1.00a
- Phyinit: 1.01a

------------------------------------------------------------------

Version 0.40a 
Apr 18, 2016

Changes from version 0.30a
(mandatory)

- Released initial ATE firmware (replaces placeholder version in prior
  releases).
- Updated 1D firmware for DDR3/DDR4/LPDDR3/LPDDR4, supporting all training
  steps.
- Released initial 2D firmware for DDR4/LPDDR4 (replaces placeholder
  version in prior releases).

------------------------------------------------------------------

Version 0.30a 
Mar 21, 2016

Changes from version 0.20a
(recommended)

- Reorganized and expanded firmware deliverables as follows:-
-- ate (placeholder only - will be populated in later release)
-- ddr3 (previously called ddr3_udimm)
-- ddr4 (previously called ddr4_udimm)
-- ddr4_2d (placeholder only - will be populated in later release)
-- lpddr3
-- lpddr4
-- lpddr4_2d (placeholder only - will be populated in later release)

------------------------------------------------------------------

Version 0.20a
Oct 23, 2015

Initial release

------------------------------------------------------------------


Special Notes
-------------
- Please expect a future, updated firmware release based on Testchip
  evaluation.  Not a tapeout gating item.

