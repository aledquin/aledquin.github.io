#! /usr/bin/env perl

system ("chmod 777 $ARGV[0]");
system ("chmod 777 $ARGV[1]");
system ("chmod 777 $ARGV[2]");
system ("chmod 777 $ARGV[3]");
system ("cp $ARGV[2] $ARGV[3]");
open (Af, "<$ARGV[0]") or die "ERROR: cannot read $ARGV[0]";
open (Bf, ">$ARGV[1]") or die "ERROR: cannot write $ARGV[1]";

while (<Af>){

#AC
  $_ =~ s/dwc_ddrphyacx4_top u_DWC_DDRPHYACX4_0/`ifdef AC_EW_0\n  dwc_ddrphyacx4_top_ew u_DWC_DDRPHYACX4_0\n`else\n  dwc_ddrphyacx4_top_ns u_DWC_DDRPHYACX4_0 \n`endif/;  
  $_ =~ s/dwc_ddrphyacx4_top u_DWC_DDRPHYACX4_1$/`ifdef AC_EW_1\n  dwc_ddrphyacx4_top_ew u_DWC_DDRPHYACX4_1\n`else\n  dwc_ddrphyacx4_top_ns u_DWC_DDRPHYACX4_1\n`endif/;  
  for ($i=2; $i<12; $i++){    
  $_ =~ s/dwc_ddrphyacx4_top u_DWC_DDRPHYACX4_$i/`ifdef AC_EW_$i\n  dwc_ddrphyacx4_top_ew u_DWC_DDRPHYACX4_$i\n`else\n  dwc_ddrphyacx4_top_ns u_DWC_DDRPHYACX4_$i \n`endif/;
  }      

#Dbyte
 for ($i=0; $i<10; $i++){    
  $_ =~ s/dwc_ddrphydbyte_top u_DWC_DDRPHYDBYTE_$i\ \(/`ifdef DBYTE_EW_$i\n  dwc_ddrphydbyte_top_ew u_DWC_DDRPHYDBYTE_$i\ \(\n`else\n\ dwc_ddrphydbyte_top_ns u_DWC_DDRPHYDBYTE_$i\ \(\n`endif/;}  

   
   print Bf $_;
  }

  print "Generate successfully: dwc_ddrphy_top.v for Gatesim without SDF\n";


