#! /usr/bin/env perl


my $delay;
$delay=$ARGV[4];


system ("chmod 777 $ARGV[0]");
system ("chmod 777 $ARGV[1]");
open (Af, "<$ARGV[0]") or die "ERROR: cannot read $ARGV[0]";
open (Bf, ">$ARGV[1]") or die "ERROR: cannot write $ARGV[1]";

while (<Af>){

#master
  $_ =~ s/wire \[15:0\] PUB_MASTER_csrPllTestMode      ;/wire \[15:0\] PUB_MASTER_csrPllTestMode      ; 
        wire PUB_MASTER_PwrOkIn_dly;
        wire PUB_MASTER_Reset_dly;
        wire PUB_MASTER_PclkEnAsync_dly;
        wire [1:0] PUB_MASTER_PhyInitSync_dly;
        wire PUB_MASTER_Cmpdig_CmpanaEn_dly;
        wire PUB_MASTER_Cmpdig_CalCmpr_dly;
        wire PUB_MASTER_Cmpdig_CalExt_dly;
        wire PUB_MASTER_Cmpdig_CalInt_dly;
        wire [7:0] PUB_MASTER_Cmpdig_CalDac_dly;
        wire [1:0] PUB_MASTER_Cmpdig_CalRef_dly;
        wire PUB_MASTER_Cmpdig_CmprBiasPowerUp_dly;
        wire [3:0] PUB_MASTER_calDrvMode_dly;
        wire [11:0]  PUB_MASTER_calDrvPU_dly;
        wire [11:0] PUB_MASTER_calDrvPD_dly;
        wire [30:0] PUB_MASTER_calDrvPdTestValTh_dly;
        wire [30:0] PUB_MASTER_calDrvPuTestValTh_dly;
        wire PUB_MASTER_CmpAnaClkEn_dly;
        wire PUB_MASTER_dfi_reset_n_dly;
        wire PUB_MASTER_csrProtectMemReset_dly;
        wire PUB_MASTER_csrMemResetLValue_dly;
        wire PUB_MASTER_csrUcDctSane_dly;
        wire [1:0] PUB_MASTER_csrTestBumpEn_dly;
        wire PUB_MASTER_csrPllReset_dly;
        wire PUB_MASTER_csrPllBypassMode_dly;
        wire [1:0] PUB_BypassModeEnMASTER_dly;
        wire [1:0] PUB_BypassOutEnMASTER_dly;
        wire [1:0] PUB_BypassOutDataMASTER_dly;/; 


  $_ =~ s/dwc_ddrphymaster_top u_DWC_DDRPHYMASTER_top \(/
     assign #(0.050) PUB_MASTER_PwrOkIn_dly = PUB_MASTER_PwrOkIn;
     assign #(0.050) PUB_MASTER_Reset_dly = PUB_MASTER_Reset;
     assign #($delay) PUB_MASTER_PclkEnAsync_dly = PUB_MASTER_PclkEnAsync;
     assign #($delay) PUB_MASTER_PhyInitSync_dly = PUB_MASTER_PhyInitSync;
     assign #($delay) PUB_MASTER_Cmpdig_CmpanaEn_dly = PUB_MASTER_Cmpdig_CmpanaEn;
     assign #($delay) PUB_MASTER_Cmpdig_CalCmpr_dly = PUB_MASTER_Cmpdig_CalCmpr;
     assign #($delay) PUB_MASTER_Cmpdig_CalExt_dly = PUB_MASTER_Cmpdig_CalExt;
     assign #($delay) PUB_MASTER_Cmpdig_CalInt_dly = PUB_MASTER_Cmpdig_CalInt;
     assign #($delay) PUB_MASTER_Cmpdig_CalDac_dly = PUB_MASTER_Cmpdig_CalDac;
     assign #($delay) PUB_MASTER_Cmpdig_CalRef_dly = PUB_MASTER_Cmpdig_CalRef;
     assign #($delay) PUB_MASTER_Cmpdig_CmprBiasPowerUp_dly = PUB_MASTER_Cmpdig_CmprBiasPowerUp;
     assign #($delay) PUB_MASTER_calDrvMode_dly = PUB_MASTER_calDrvMode;
     assign #($delay) PUB_MASTER_calDrvPU_dly = PUB_MASTER_calDrvPU;
     assign #($delay) PUB_MASTER_calDrvPD_dly = PUB_MASTER_calDrvPD;
     assign #($delay) PUB_MASTER_calDrvPdTestValTh_dly = PUB_MASTER_calDrvPdTestValTh;
     assign #($delay) PUB_MASTER_calDrvPuTestValTh_dly = PUB_MASTER_calDrvPuTestValTh;
     assign #($delay) PUB_MASTER_CmpAnaClkEn_dly = PUB_MASTER_CmpAnaClkEn;
     assign #($delay) PUB_MASTER_dfi_reset_n_dly = PUB_MASTER_dfi_reset_n;
     assign #(0.050) PUB_MASTER_csrProtectMemReset_dly = PUB_MASTER_csrProtectMemReset;
     assign #(0.050) PUB_MASTER_csrMemResetLValue_dly = PUB_MASTER_csrMemResetLValue;
     assign #($delay) PUB_MASTER_csrUcDctSane_dly = PUB_MASTER_csrUcDctSane;
     assign #(0.050) PUB_MASTER_csrTestBumpEn_dly = PUB_MASTER_csrTestBumpEn;
     assign #(0.050) PUB_MASTER_csrPllReset_dly = PUB_MASTER_csrPllReset;
     assign #($delay) PUB_MASTER_csrPllBypassMode_dly = PUB_MASTER_csrPllBypassMode;
     assign #($delay) PUB_BypassModeEnMASTER_dly = PUB_BypassModeEnMASTER;
     assign #($delay) PUB_BypassOutEnMASTER_dly = PUB_BypassOutEnMASTER;
     assign #($delay) PUB_BypassOutDataMASTER_dly = PUB_BypassOutDataMASTER;
     dwc_ddrphymaster_top u_DWC_DDRPHYMASTER_top (
/;

  $_ =~ s/ .PwrOk                  \(PUB_MASTER_PwrOkIn          \),/ .PwrOk                  \(PUB_MASTER_PwrOkIn_dly          \),/;
  $_ =~ s/ .Reset                  \(PUB_MASTER_Reset            \),/ .Reset                  (PUB_MASTER_Reset_dly            ),/;

  $_ =~ s/ .PclkEnAsync            \(PUB_MASTER_PclkEnAsync \)/ .PclkEnAsync            (PUB_MASTER_PclkEnAsync_dly )/;
  $_ =~ s/ .PhyInitSync            \(PUB_MASTER_PhyInitSync \)/ .PhyInitSync            (PUB_MASTER_PhyInitSync_dly )/;
  $_ =~ s/ .Cmpdig_CmpanaEn        \(PUB_MASTER_Cmpdig_CmpanaEn \),/ .Cmpdig_CmpanaEn        (PUB_MASTER_Cmpdig_CmpanaEn_dly ),/;
  $_ =~ s/ .Cmpdig_CalCmpr         \(PUB_MASTER_Cmpdig_CalCmpr \),/ .Cmpdig_CalCmpr         (PUB_MASTER_Cmpdig_CalCmpr_dly ),/;
  $_ =~ s/ .Cmpdig_CalExt          \(PUB_MASTER_Cmpdig_CalExt \),/ .Cmpdig_CalExt          (PUB_MASTER_Cmpdig_CalExt_dly ),/;
  $_ =~ s/ .Cmpdig_CalInt          \(PUB_MASTER_Cmpdig_CalInt \),/ .Cmpdig_CalInt          (PUB_MASTER_Cmpdig_CalInt_dly ),/;
  $_ =~ s/ .Cmpdig_CalDac          \(PUB_MASTER_Cmpdig_CalDac \),/ .Cmpdig_CalDac          (PUB_MASTER_Cmpdig_CalDac_dly ),/;
  $_ =~ s/ .Cmpdig_CalRef          \(PUB_MASTER_Cmpdig_CalRef \),/ .Cmpdig_CalRef          (PUB_MASTER_Cmpdig_CalRef_dly ),/;          
  $_ =~ s/ .Cmpdig_CmprBiasPowerUp \(PUB_MASTER_Cmpdig_CmprBiasPowerUp \),/ .Cmpdig_CmprBiasPowerUp (PUB_MASTER_Cmpdig_CmprBiasPowerUp_dly ),/;   
                        
  $_ =~ s/ .calDrvMode             \(PUB_MASTER_calDrvMode  \),/ .calDrvMode             (PUB_MASTER_calDrvMode_dly  ),/;
  $_ =~ s/ .calDrvPU               \(PUB_MASTER_calDrvPU \),/ .calDrvPU               (PUB_MASTER_calDrvPU_dly ),/;
  $_ =~ s/ .calDrvPD               \(PUB_MASTER_calDrvPD \),/ .calDrvPD               (PUB_MASTER_calDrvPD_dly ),/;
                       
  $_ =~ s/ .calDrvPdTestValTh      \(PUB_MASTER_calDrvPdTestValTh \),/ .calDrvPdTestValTh      (PUB_MASTER_calDrvPdTestValTh_dly ),/;
  $_ =~ s/ .calDrvPuTestValTh      \(PUB_MASTER_calDrvPuTestValTh \),/ .calDrvPuTestValTh      (PUB_MASTER_calDrvPuTestValTh_dly ),/;
  $_ =~ s/ .CmpAnaClkEn            \(PUB_MASTER_CmpAnaClkEn\),/ .CmpAnaClkEn            (PUB_MASTER_CmpAnaClkEn_dly),/;


  $_ =~ s/ .dfi_reset_n            \(PUB_MASTER_dfi_reset_n\),/ .dfi_reset_n            (PUB_MASTER_dfi_reset_n_dly),/;
  $_ =~ s/ .csrProtectMemReset    \(PUB_MASTER_csrProtectMemReset   \),/ .csrProtectMemReset    (PUB_MASTER_csrProtectMemReset_dly   ),/;
  $_ =~ s/ .csrMemResetLValue     \(PUB_MASTER_csrMemResetLValue    \),/ .csrMemResetLValue     (PUB_MASTER_csrMemResetLValue_dly    ),/;
  $_ =~ s/ .csrUcDctSane          \(PUB_MASTER_csrUcDctSane         \),/ .csrUcDctSane          (PUB_MASTER_csrUcDctSane_dly         ),/;
  $_ =~ s/ .csrTestBumpEn         \(PUB_MASTER_csrTestBumpEn        \),/ .csrTestBumpEn         (PUB_MASTER_csrTestBumpEn_dly        ),/;
  $_=~ s/ .csrPllReset           \(PUB_MASTER_csrPllReset          \),/ .csrPllReset           (PUB_MASTER_csrPllReset_dly          ),/;
  $_=~ s/ .csrPllBypassMode      \(PUB_MASTER_csrPllBypassMode     \),/ .csrPllBypassMode      (PUB_MASTER_csrPllBypassMode_dly     ),/;
  $_=~ s/ .BypassModeEn          \(PUB_BypassModeEnMASTER  \),/ .BypassModeEn          (PUB_BypassModeEnMASTER_dly  ),/;
  $_=~ s/ .BypassOutEn           \(PUB_BypassOutEnMASTER   \),/ .BypassOutEn           (PUB_BypassOutEnMASTER_dly   ),/;
  $_=~ s/ .BypassOutData         \(PUB_BypassOutDataMASTER \),/ .BypassOutData         (PUB_BypassOutDataMASTER_dly ),/;


# AC
  $_ =~ s/dwc_ddrphyacx4_top u_DWC_DDRPHYACX4_0/`ifdef AC_EW_0\n  dwc_ddrphyacx4_top_ew u_DWC_DDRPHYACX4_0\n`else\n  dwc_ddrphyacx4_top_ns u_DWC_DDRPHYACX4_0 \n`endif/;  
  $_ =~ s/dwc_ddrphyacx4_top u_DWC_DDRPHYACX4_1$/`ifdef AC_EW_1\n  dwc_ddrphyacx4_top_ew u_DWC_DDRPHYACX4_1\n`else\n  dwc_ddrphyacx4_top_ns u_DWC_DDRPHYACX4_1\n`endif/;  
  for ($i=2; $i<12; $i++){    $_ =~ s/dwc_ddrphyacx4_top u_DWC_DDRPHYACX4_$i/`ifdef AC_EW_$i\n  dwc_ddrphyacx4_top_ew u_DWC_DDRPHYACX4_$i\n`else\n  dwc_ddrphyacx4_top_ns u_DWC_DDRPHYACX4_$i \n`endif/;}      

  for ($i=0; $i<$ARGV[2]; $i++){
    for ($j=0; $j<4; $j++){
    $_ =~ s/wire  \[3\:0\] PUB_ANIB$i\_TxEnLn$j         ;/wire  \[3\:0\] PUB_ANIB$i\_TxEnLn$j         ;\n
        wire \[3\:0\] PUB_ANIB$i\_TxDatLn$j\_dly         ;
        wire \[3\:0\] PUB_ANIB$i\_TxEnLn$j\_dly         ;/; 
    }   

    $_ =~ s/wire \[15\:0\] ANIB$i\_PUB_PrbsErrCnt       ;/wire \[15\:0\] ANIB$i\_PUB_PrbsErrCnt       ;\n
        wire [5:0] PUB_ANIB$i\_csrMtestMuxSel_dly;
        wire PUB_ANIB$i\_TxDatPtrInit_dly;
        wire PUB_ANIB$i\_TxCmdPtrInit_dly;
        wire PUB_ANIB$i\_TxRdPtrInit_dly;

        wire [3:0] PUB_ANIB$i\_TxDllClkEn_dly;
        wire [3:0] PUB_ANIB$i\_TxDllUpdate_dly;
        wire [3:0] PUB_ANIB$i\_TxPrbsClkEn_dly;
        wire [3:0] PUB_ANIB$i\_DbyteClkEn_dly;
        wire [3:0] PUB_ANIB$i\_DbyteClkEnLock_dly;
        wire PUB_ANIB$i\_CoreLoopbackMode_dly;
        wire PUB_ANIB$i\_RxPowerDown_dly;
        wire PUB_ANIB$i\_TxDllCalSlowClkSel_dly;
        wire PUB_ANIB$i\_MDllCalSlowClkSel_dly;
        wire PUB_ANIB$i\_TxDllCalMode_dly;
        wire PUB_ANIB$i\_MDllCalMode_dly;
        wire PUB_ANIB$i\_TxDllCalEn_dly;
        wire PUB_ANIB$i\_MDllCalEn_dly;
        wire PUB_ANIB$i\_TxDllCalClkEn_dly;
        wire PUB_ANIB$i\_MDllCalClkEn_dly;
        wire PUB_ANIB$i\_TxDllCalSampEn_dly;
        wire PUB_ANIB$i\_MDllCalSampEn_dly;
        wire PUB_ANIB$i\_TxDllCalPhaseUpdate_dly;
        wire PUB_ANIB$i\_MDllCalPhaseUpdate_dly;
        wire [8:0] PUB_ANIB$i\_TxDllPhaseIn_dly;
        wire [8:0] PUB_ANIB$i\_MDllPhaseIn_dly;
        wire PUB_ANIB$i\_DDRLoopbackMode_dly;/;        

        $_=~ s/dwc_ddrphymaster_top u_DWC_DDRPHYMASTER_top \(/assign #($delay) PUB_ANIB$i\_csrMtestMuxSel_dly = PUB_ANIB$i\_csrMtestMuxSel;\n
        assign #($delay) PUB_ANIB$i\_TxDatPtrInit_dly = PUB_ANIB$i\_TxDatPtrInit;
        assign #($delay) PUB_ANIB$i\_TxCmdPtrInit_dly = PUB_ANIB$i\_TxCmdPtrInit;
        assign #($delay) PUB_ANIB$i\_TxRdPtrInit_dly = PUB_ANIB$i\_TxRdPtrInit;
        assign #($delay) PUB_ANIB$i\_TxDatLn0_dly = PUB_ANIB$i\_TxDatLn0;
        assign #($delay) PUB_ANIB$i\_TxDatLn1_dly = PUB_ANIB$i\_TxDatLn1;
        assign #($delay) PUB_ANIB$i\_TxDatLn2_dly = PUB_ANIB$i\_TxDatLn2;
        assign #($delay) PUB_ANIB$i\_TxDatLn3_dly = PUB_ANIB$i\_TxDatLn3;
        assign #($delay) PUB_ANIB$i\_TxEnLn0_dly = PUB_ANIB$i\_TxEnLn0;
        assign #($delay) PUB_ANIB$i\_TxEnLn1_dly = PUB_ANIB$i\_TxEnLn1;
        assign #($delay) PUB_ANIB$i\_TxEnLn2_dly = PUB_ANIB$i\_TxEnLn2;
        assign #($delay) PUB_ANIB$i\_TxEnLn3_dly = PUB_ANIB$i\_TxEnLn3;
        assign #($delay) PUB_ANIB$i\_TxDllClkEn_dly = PUB_ANIB$i\_TxDllClkEn;
        assign #($delay) PUB_ANIB$i\_TxDllUpdate_dly = PUB_ANIB$i\_TxDllUpdate;
        assign #($delay) PUB_ANIB$i\_TxPrbsClkEn_dly = PUB_ANIB$i\_TxPrbsClkEn;
        assign #($delay) PUB_ANIB$i\_DbyteClkEn_dly = PUB_ANIB$i\_DbyteClkEn;
        assign #($delay) PUB_ANIB$i\_DbyteClkEnLock_dly = PUB_ANIB$i\_DbyteClkEnLock;
        assign #($delay) PUB_ANIB$i\_CoreLoopbackMode_dly = PUB_ANIB$i\_CoreLoopbackMode;
        assign #($delay) PUB_ANIB$i\_RxPowerDown_dly = PUB_ANIB$i\_RxPowerDown;
        assign #($delay) PUB_ANIB$i\_TxDllCalSlowClkSel_dly = PUB_ANIB$i\_TxDllCalSlowClkSel;
        assign #($delay) PUB_ANIB$i\_MDllCalSlowClkSel_dly = PUB_ANIB$i\_MDllCalSlowClkSel;
        assign #($delay) PUB_ANIB$i\_TxDllCalMode_dly = PUB_ANIB$i\_TxDllCalMode;
        assign #($delay) PUB_ANIB$i\_MDllCalMode_dly = PUB_ANIB$i\_MDllCalMode;
        assign #($delay) PUB_ANIB$i\_TxDllCalEn_dly = PUB_ANIB$i\_TxDllCalEn;
        assign #($delay) PUB_ANIB$i\_MDllCalEn_dly = PUB_ANIB$i\_MDllCalEn;
        assign #($delay) PUB_ANIB$i\_TxDllCalClkEn_dly = PUB_ANIB$i\_TxDllCalClkEn;
        assign #($delay) PUB_ANIB$i\_MDllCalClkEn_dly = PUB_ANIB$i\_MDllCalClkEn;
        assign #($delay) PUB_ANIB$i\_TxDllCalSampEn_dly = PUB_ANIB$i\_TxDllCalSampEn;
        assign #($delay) PUB_ANIB$i\_MDllCalSampEn_dly = PUB_ANIB$i\_MDllCalSampEn;
        assign #($delay) PUB_ANIB$i\_TxDllCalPhaseUpdate_dly = PUB_ANIB$i\_TxDllCalPhaseUpdate;
        assign #($delay) PUB_ANIB$i\_MDllCalPhaseUpdate_dly = PUB_ANIB$i\_MDllCalPhaseUpdate;
        assign #($delay) PUB_ANIB$i\_TxDllPhaseIn_dly = PUB_ANIB$i\_TxDllPhaseIn;
        assign #($delay) PUB_ANIB$i\_MDllPhaseIn_dly = PUB_ANIB$i\_MDllPhaseIn;
        assign #($delay) PUB_ANIB$i\_DDRLoopbackMode_dly = PUB_ANIB$i\_DDRLoopbackMode;
        dwc_ddrphymaster_top u_DWC_DDRPHYMASTER_top \(/;       

        $_ =~ s/ .PubTxDatPtrInit\(PUB_ANIB$i\_TxDatPtrInit\)/ .PubTxDatPtrInit(PUB_ANIB$i\_TxDatPtrInit_dly)/; 

        $_ =~ s/ .PubTxCmdPtrInit\(PUB_ANIB$i\_TxCmdPtrInit\)/ .PubTxCmdPtrInit(PUB_ANIB$i\_TxCmdPtrInit_dly)/; 

        $_ =~ s/ .PubTxRdPtrInit \(PUB_ANIB$i\_TxRdPtrInit \)/ .PubTxRdPtrInit (PUB_ANIB$i\_TxRdPtrInit_dly )/; 
 
        for ($j=0; $j<4; $j++){
         $_ =~ s/ .PubTxDatLn$j      \(PUB_ANIB$i\_TxDatLn$j/ .PubTxDatLn$j      \(PUB_ANIB$i\_TxDatLn$j\_dly/;
         $_ =~ s/ .PubTxEnLn$j       \(PUB_ANIB$i\_TxEnLn$j/ .PubTxEnLn$j       \(PUB_ANIB$i\_TxEnLn$j\_dly/;
         } 

        $_ =~ s/ .PubTxDllClkEn   \(PUB_ANIB$i\_TxDllClkEn \)/ .PubTxDllClkEn   (PUB_ANIB$i\_TxDllClkEn_dly )/; 

        $_ =~ s/ .PubTxDllUpdate  \(PUB_ANIB$i\_TxDllUpdate\)/ .PubTxDllUpdate  (PUB_ANIB$i\_TxDllUpdate_dly)/; 

        $_ =~ s/ .PubPrbsClkEn    \(PUB_ANIB$i\_TxPrbsClkEn\)/ .PubPrbsClkEn    (PUB_ANIB$i\_TxPrbsClkEn_dly)/; 

        $_ =~ s/ .PubDbyteClkEn   \(PUB_ANIB$i\_DbyteClkEn \)/ .PubDbyteClkEn   (PUB_ANIB$i\_DbyteClkEn_dly )/; 

        $_ =~ s/ .DbyteClkEnLock  \(PUB_ANIB$i\_DbyteClkEnLock \)/ .DbyteClkEnLock  (PUB_ANIB$i\_DbyteClkEnLock_dly )/; 

        $_ =~ s/ .CoreLoopbackMode\(PUB_ANIB$i\_CoreLoopbackMode\)/ .CoreLoopbackMode(PUB_ANIB$i\_CoreLoopbackMode_dly)/; 

        $_ =~ s/ .RxPowerDown     \(PUB_ANIB$i\_RxPowerDown\)/ .RxPowerDown     (PUB_ANIB$i\_RxPowerDown_dly)/; 

        $_ =~ s/ .TxDllCalSlowClkSel  \(PUB_ANIB$i\_TxDllCalSlowClkSel\)/ .TxDllCalSlowClkSel  (PUB_ANIB$i\_TxDllCalSlowClkSel_dly)/; 

        $_ =~ s/ .MDllCalSlowClkSel   \(PUB_ANIB$i\_MDllCalSlowClkSel  \)/ .MDllCalSlowClkSel   (PUB_ANIB$i\_MDllCalSlowClkSel_dly  )/; 
        $_ =~ s/ .TxDllCalMode        \(PUB_ANIB$i\_TxDllCalMode        \)/ .TxDllCalMode        (PUB_ANIB$i\_TxDllCalMode_dly        )/; 

        $_ =~ s/ .TxDllCalEn          \(PUB_ANIB$i\_TxDllCalEn          \)/ .TxDllCalEn          (PUB_ANIB$i\_TxDllCalEn_dly          )/; 

        $_ =~ s/ .TxDllCalClkEn       \(PUB_ANIB$i\_TxDllCalClkEn       \)/ .TxDllCalClkEn       (PUB_ANIB$i\_TxDllCalClkEn_dly       )/; 

        $_ =~ s/ .TxDllCalSampEn      \(PUB_ANIB$i\_TxDllCalSampEn      \)/ .TxDllCalSampEn      (PUB_ANIB$i\_TxDllCalSampEn_dly      )/; 

        $_ =~ s/ .TxDllCalPhaseUpdate \(PUB_ANIB$i\_TxDllCalPhaseUpdate \)/ .TxDllCalPhaseUpdate (PUB_ANIB$i\_TxDllCalPhaseUpdate_dly )/; 

        $_ =~ s/ .TxDllPhaseIn        \(PUB_ANIB$i\_TxDllPhaseIn        \)/ .TxDllPhaseIn        (PUB_ANIB$i\_TxDllPhaseIn_dly        )/; 

        $_ =~ s/ .MDllCalMode        \(PUB_ANIB$i\_MDllCalMode        \)/ .MDllCalMode        (PUB_ANIB$i\_MDllCalMode_dly        )/; 

        $_ =~ s/ .MDllCalEn          \(PUB_ANIB$i\_MDllCalEn          \)/ .MDllCalEn          (PUB_ANIB$i\_MDllCalEn_dly          )/; 

        $_ =~ s/ .MDllCalClkEn       \(PUB_ANIB$i\_MDllCalClkEn       \)/ .MDllCalClkEn       (PUB_ANIB$i\_MDllCalClkEn_dly       )/; 

        $_ =~ s/ .MDllCalSampEn      \(PUB_ANIB$i\_MDllCalSampEn      \)/ .MDllCalSampEn      (PUB_ANIB$i\_MDllCalSampEn_dly      )/; 

        $_ =~ s/ .MDllCalPhaseUpdate \(PUB_ANIB$i\_MDllCalPhaseUpdate \)/ .MDllCalPhaseUpdate (PUB_ANIB$i\_MDllCalPhaseUpdate_dly )/; 

        $_ =~ s/ .MDllPhaseIn        \(PUB_ANIB$i\_MDllPhaseIn        \)/ .MDllPhaseIn        (PUB_ANIB$i\_MDllPhaseIn_dly        )/; 

        $_ =~ s/ .DDRLoopbackMode \(PUB_ANIB$i\_DDRLoopbackMode\)/ .DDRLoopbackMode (PUB_ANIB$i\_DDRLoopbackMode_dly)/; 

        $_ =~ s/ .MtestMuxSel  \( PUB_ANIB$i\_csrMtestMuxSel\)/ .MtestMuxSel  ( PUB_ANIB$i\_csrMtestMuxSel_dly)/;

  }

#Dbyte
 for ($i=0; $i<10; $i++){    $_ =~ s/dwc_ddrphydbyte_top u_DWC_DDRPHYDBYTE_$i \(/`ifdef DBYTE_EW_$i\n  dwc_ddrphydbyte_top_ew u_DWC_DDRPHYDBYTE_$i (\n`else\ndwc_ddrphydbyte_top_ns u_DWC_DDRPHYDBYTE_$i (   \n`endif/;}  

  for ($i=0; $i<$ARGV[3]; $i++){

    for ($j=0; $j<10; $j++){
      $_ =~ s/wire  \[3\:0\] PUB_DAT$i\_TxCmdFifoDlUp_ln$j ;/wire  \[3\:0\] PUB_DAT$i\_TxCmdFifoDlUp_ln$j ;\n
          wire \[11\:0\] PUB_DAT$i\_TxDatEnWk_ln$j\_dly;
          wire \[3\:0\] PUB_DAT$i\_TxDatFifoWrEn_ln$j\_dly;
          wire \[3\:0\] PUB_DAT$i\_TxCmdFifoDlUp_ln$j\_dly;/;     
    }
    for ($j=0; $j<2; $j++){
      $_ =~ s/wire  \[3\:0\] PUB_DAT$i\_csrTxPreP_b$j          ;/wire  \[3\:0\] PUB_DAT$i\_csrTxPreP_b$j          ;\n
         wire \[1\:0\] PUB_DAT$i\_csrDfeCtrl_b$j\_dly;
         wire \[2\:0\] PUB_DAT$i\_csrMajorModeDbyte_b$j\_dly;/; 
    }
    for ($j=0; $j<16; $j++){
      $_ =~ s/wire  \[8\:0\] PUB_DAT$i\_LcdlCalPhase_n$j;/wire  \[8\:0\] PUB_DAT$i\_LcdlCalPhase_n$j;\n
         wire  \[8\:0\] PUB_DAT$i\_LcdlCalPhase_n$j\_dly;/;  
    }

    $_ =~ s/wire  \[6:0\] PUB_DAT$i\_BDLCalPhase;/wire  [6:0] PUB_DAT$i\_BDLCalPhase;\n
        wire PUB_DAT$i\_RxCmdFifoWrPtrInit_dly;
        wire [19:0] PUB_DAT$i\_RxCmd_u1_dly;
        wire [19:0] PUB_DAT$i\_RxCmd_u0_dly;
        wire PUB_DAT$i\_RxDatRdPtrInit_dly;
        wire [1:0] PUB_DAT$i\_RxDatVal_dly;
        wire PUB_DAT$i\_TxCmdFifoWrPtrInit_dly;
        wire PUB_DAT$i\_TxDatFifoWrPtrInit_dly;
        wire [90:0] PUB_DAT$i\_LcdlTxDly1xTgBndl_dly;
        wire [117:0] PUB_DAT$i\_LcdlRxDly1xTgBndl_dly;
        wire [126:0] PUB_DAT$i\_csrVrefDACBndl_dly;
        wire PUB_DAT$i\_CoreLoopbackMode_dly;
        wire PUB_DAT$i\_RxEnTrain_dly;
        wire [8:0] PUB_DAT$i\_PowerDownRcvr_dly;
        wire PUB_DAT$i\_csrRxFifoRdPtrOvr_dly;
        wire [2:0]  PUB_DAT$i\_csrRxFifoRdPtr_dly;
        wire [24:0] PUB_DAT$i\_DlyTestClkEn_dly;
        wire [6:0]  PUB_DAT$i\_BDLCalPhase_dly;
        wire PUB_DAT$i\_LcdlCalMode_dly;
        wire PUB_DAT$i\_LcdlCalEn_dly;
        wire PUB_DAT$i\_LcdlCalPhaseUpdate_dly;
        wire PUB_DAT$i\_LcdlCalClkEn_dly;
        wire PUB_DAT$i\_LcdlCalSampEn_dly;/;


        $_ =~ s/dwc_ddrphymaster_top u_DWC_DDRPHYMASTER_top \(/assign #($delay) PUB_DAT$i\_RxCmdFifoWrPtrInit_dly = PUB_DAT$i\_RxCmdFifoWrPtrInit;
assign #($delay) PUB_DAT$i\_RxCmd_u1_dly = PUB_DAT$i\_RxCmd_u1;
assign #($delay) PUB_DAT$i\_RxCmd_u0_dly = PUB_DAT$i\_RxCmd_u0;
assign #($delay) PUB_DAT$i\_RxDatRdPtrInit_dly = PUB_DAT$i\_RxDatRdPtrInit;
assign #($delay) PUB_DAT$i\_RxDatVal_dly = PUB_DAT$i\_RxDatVal;
assign #($delay) PUB_DAT$i\_TxCmdFifoWrPtrInit_dly = PUB_DAT$i\_TxCmdFifoWrPtrInit;
assign #($delay) PUB_DAT$i\_TxDatFifoWrPtrInit_dly = PUB_DAT$i\_TxDatFifoWrPtrInit;
assign #($delay) PUB_DAT$i\_TxDatEnWk_ln0_dly = PUB_DAT$i\_TxDatEnWk_ln0;
assign #($delay) PUB_DAT$i\_TxDatEnWk_ln1_dly = PUB_DAT$i\_TxDatEnWk_ln1;
assign #($delay) PUB_DAT$i\_TxDatEnWk_ln2_dly = PUB_DAT$i\_TxDatEnWk_ln2;
assign #($delay) PUB_DAT$i\_TxDatEnWk_ln3_dly = PUB_DAT$i\_TxDatEnWk_ln3;
assign #($delay) PUB_DAT$i\_TxDatEnWk_ln4_dly = PUB_DAT$i\_TxDatEnWk_ln4;
assign #($delay) PUB_DAT$i\_TxDatEnWk_ln5_dly = PUB_DAT$i\_TxDatEnWk_ln5;
assign #($delay) PUB_DAT$i\_TxDatEnWk_ln6_dly = PUB_DAT$i\_TxDatEnWk_ln6;
assign #($delay) PUB_DAT$i\_TxDatEnWk_ln7_dly = PUB_DAT$i\_TxDatEnWk_ln7;
assign #($delay) PUB_DAT$i\_TxDatEnWk_ln8_dly = PUB_DAT$i\_TxDatEnWk_ln8;
assign #($delay) PUB_DAT$i\_TxDatEnWk_ln9_dly = PUB_DAT$i\_TxDatEnWk_ln9;
assign #($delay) PUB_DAT$i\_TxDatFifoWrEn_ln0_dly = PUB_DAT$i\_TxDatFifoWrEn_ln0;
assign #($delay) PUB_DAT$i\_TxDatFifoWrEn_ln1_dly = PUB_DAT$i\_TxDatFifoWrEn_ln1;
assign #($delay) PUB_DAT$i\_TxDatFifoWrEn_ln2_dly = PUB_DAT$i\_TxDatFifoWrEn_ln2;
assign #($delay) PUB_DAT$i\_TxDatFifoWrEn_ln3_dly = PUB_DAT$i\_TxDatFifoWrEn_ln3;
assign #($delay) PUB_DAT$i\_TxDatFifoWrEn_ln4_dly = PUB_DAT$i\_TxDatFifoWrEn_ln4;
assign #($delay) PUB_DAT$i\_TxDatFifoWrEn_ln5_dly = PUB_DAT$i\_TxDatFifoWrEn_ln5;
assign #($delay) PUB_DAT$i\_TxDatFifoWrEn_ln6_dly = PUB_DAT$i\_TxDatFifoWrEn_ln6;
assign #($delay) PUB_DAT$i\_TxDatFifoWrEn_ln7_dly = PUB_DAT$i\_TxDatFifoWrEn_ln7;
assign #($delay) PUB_DAT$i\_TxDatFifoWrEn_ln8_dly = PUB_DAT$i\_TxDatFifoWrEn_ln8;
assign #($delay) PUB_DAT$i\_TxDatFifoWrEn_ln9_dly = PUB_DAT$i\_TxDatFifoWrEn_ln9;
assign #($delay) PUB_DAT$i\_TxCmdFifoDlUp_ln0_dly = PUB_DAT$i\_TxCmdFifoDlUp_ln0;
assign #($delay) PUB_DAT$i\_TxCmdFifoDlUp_ln1_dly = PUB_DAT$i\_TxCmdFifoDlUp_ln1;
assign #($delay) PUB_DAT$i\_TxCmdFifoDlUp_ln2_dly = PUB_DAT$i\_TxCmdFifoDlUp_ln2;
assign #($delay) PUB_DAT$i\_TxCmdFifoDlUp_ln3_dly = PUB_DAT$i\_TxCmdFifoDlUp_ln3;
assign #($delay) PUB_DAT$i\_TxCmdFifoDlUp_ln4_dly = PUB_DAT$i\_TxCmdFifoDlUp_ln4;
assign #($delay) PUB_DAT$i\_TxCmdFifoDlUp_ln5_dly = PUB_DAT$i\_TxCmdFifoDlUp_ln5;
assign #($delay) PUB_DAT$i\_TxCmdFifoDlUp_ln6_dly = PUB_DAT$i\_TxCmdFifoDlUp_ln6;
assign #($delay) PUB_DAT$i\_TxCmdFifoDlUp_ln7_dly = PUB_DAT$i\_TxCmdFifoDlUp_ln7;
assign #($delay) PUB_DAT$i\_TxCmdFifoDlUp_ln8_dly = PUB_DAT$i\_TxCmdFifoDlUp_ln8;
assign #($delay) PUB_DAT$i\_TxCmdFifoDlUp_ln9_dly = PUB_DAT$i\_TxCmdFifoDlUp_ln9;
assign #($delay) PUB_DAT$i\_LcdlTxDly1xTgBndl_dly = PUB_DAT$i\_LcdlTxDly1xTgBndl;
assign #($delay) PUB_DAT$i\_LcdlRxDly1xTgBndl_dly = PUB_DAT$i\_LcdlRxDly1xTgBndl;
assign #($delay) PUB_DAT$i\_csrVrefDACBndl_dly = PUB_DAT$i\_csrVrefDACBndl;
assign #($delay) PUB_DAT$i\_CoreLoopbackMode_dly = PUB_DAT$i\_CoreLoopbackMode;
assign #($delay) PUB_DAT$i\_RxEnTrain_dly = PUB_DAT$i\_RxEnTrain;
assign #($delay) PUB_DAT$i\_PowerDownRcvrDqs_dly = PUB_DAT$i\_PowerDownRcvrDqs;
assign #($delay) PUB_DAT$i\_PowerDownRcvr_dly = PUB_DAT$i\_PowerDownRcvr;
assign #($delay) PUB_DAT$i\_csrRxFifoRdPtrOvr_dly = PUB_DAT$i\_csrRxFifoRdPtrOvr;
assign #($delay) PUB_DAT$i\_csrRxFifoRdPtr_dly = PUB_DAT$i\_csrRxFifoRdPtr;
assign #($delay) PUB_DAT$i\_csrMajorModeDbyte_b0_dly = PUB_DAT$i\_csrMajorModeDbyte_b0;
assign #($delay) PUB_DAT$i\_csrMajorModeDbyte_b1_dly = PUB_DAT$i\_csrMajorModeDbyte_b1;
assign #($delay) PUB_DAT$i\_csrDfeCtrl_b0_dly = PUB_DAT$i\_csrDfeCtrl_b0;
assign #($delay) PUB_DAT$i\_csrDfeCtrl_b1_dly = PUB_DAT$i\_csrDfeCtrl_b1;
assign #($delay) PUB_DAT$i\_DlyTestClkEn_dly = PUB_DAT$i\_DlyTestClkEn;
assign #($delay) PUB_DAT$i\_LcdlCalPhase_n0_dly = PUB_DAT$i\_LcdlCalPhase_n0;
assign #($delay) PUB_DAT$i\_LcdlCalPhase_n1_dly = PUB_DAT$i\_LcdlCalPhase_n1;
assign #($delay) PUB_DAT$i\_LcdlCalPhase_n2_dly = PUB_DAT$i\_LcdlCalPhase_n2;
assign #($delay) PUB_DAT$i\_LcdlCalPhase_n3_dly = PUB_DAT$i\_LcdlCalPhase_n3;
assign #($delay) PUB_DAT$i\_LcdlCalPhase_n4_dly = PUB_DAT$i\_LcdlCalPhase_n4;
assign #($delay) PUB_DAT$i\_LcdlCalPhase_n5_dly = PUB_DAT$i\_LcdlCalPhase_n5;
assign #($delay) PUB_DAT$i\_LcdlCalPhase_n6_dly = PUB_DAT$i\_LcdlCalPhase_n6;
assign #($delay) PUB_DAT$i\_LcdlCalPhase_n7_dly = PUB_DAT$i\_LcdlCalPhase_n7;
assign #($delay) PUB_DAT$i\_LcdlCalPhase_n8_dly = PUB_DAT$i\_LcdlCalPhase_n8;
assign #($delay) PUB_DAT$i\_LcdlCalPhase_n9_dly = PUB_DAT$i\_LcdlCalPhase_n9;
assign #($delay) PUB_DAT$i\_LcdlCalPhase_n10_dly = PUB_DAT$i\_LcdlCalPhase_n10;
assign #($delay) PUB_DAT$i\_LcdlCalPhase_n11_dly = PUB_DAT$i\_LcdlCalPhase_n11;
assign #($delay) PUB_DAT$i\_LcdlCalPhase_n12_dly = PUB_DAT$i\_LcdlCalPhase_n12;
assign #($delay) PUB_DAT$i\_LcdlCalPhase_n13_dly = PUB_DAT$i\_LcdlCalPhase_n13;
assign #($delay) PUB_DAT$i\_LcdlCalPhase_n14_dly = PUB_DAT$i\_LcdlCalPhase_n14;
assign #($delay) PUB_DAT$i\_LcdlCalPhase_n15_dly = PUB_DAT$i\_LcdlCalPhase_n15;
assign #($delay) PUB_DAT$i\_BDLCalPhase_dly = PUB_DAT$i\_BDLCalPhase;
assign #($delay) PUB_DAT$i\_LcdlCalMode_dly = PUB_DAT$i\_LcdlCalMode;
assign #($delay) PUB_DAT$i\_LcdlCalEn_dly = PUB_DAT$i\_LcdlCalEn;
assign #($delay) PUB_DAT$i\_LcdlCalPhaseUpdate_dly = PUB_DAT$i\_LcdlCalPhaseUpdate;
assign #($delay) PUB_DAT$i\_LcdlCalClkEn_dly = PUB_DAT$i\_LcdlCalClkEn;
assign #($delay) PUB_DAT$i\_LcdlCalSampEn_dly = PUB_DAT$i\_LcdlCalSampEn;
dwc_ddrphymaster_top u_DWC_DDRPHYMASTER_top \(/; 


    $_ =~ s/ .RxCmdFifoWrPtrInit       \(PUB_DAT$i\_RxCmdFifoWrPtrInit \),/ .RxCmdFifoWrPtrInit       (PUB_DAT$i\_RxCmdFifoWrPtrInit_dly ),/;

    $_ =~ s/ .RxCmd_u1                 \(PUB_DAT$i\_RxCmd_u1\[19:0\]     \),/ .RxCmd_u1                 (PUB_DAT$i\_RxCmd_u1_dly [19:0]     ),/;

    $_ =~ s/ .RxCmd_u0                 \(PUB_DAT$i\_RxCmd_u0\[19:0\]     \),/ .RxCmd_u0                 (PUB_DAT$i\_RxCmd_u0_dly [19:0]     ),/;

    $_ =~ s/ .RxDatRdPtrInit           \(PUB_DAT$i\_RxDatRdPtrInit     \),/ .RxDatRdPtrInit           (PUB_DAT$i\_RxDatRdPtrInit_dly     ),/;

    $_ =~ s/ .RxDatVal                 \(PUB_DAT$i\_RxDatVal           \),/ .RxDatVal                 (PUB_DAT$i\_RxDatVal_dly           ),/;

    $_ =~ s/ .TxCmdFifoWrPtrInit       \(PUB_DAT$i\_TxCmdFifoWrPtrInit \),/ .TxCmdFifoWrPtrInit       (PUB_DAT$i\_TxCmdFifoWrPtrInit_dly ),/;

    $_ =~ s/ .TxDatFifoWrPtrInit       \(PUB_DAT$i\_TxDatFifoWrPtrInit \),/ .TxDatFifoWrPtrInit       (PUB_DAT$i\_TxDatFifoWrPtrInit_dly ),/;

    for ($j=0; $j<10; $j++){
      $_ =~ s/ .TxDatEnWk_ln$j         \(PUB_DAT$i\_TxDatEnWk_ln$j/ .TxDatEnWk_ln$j         (PUB_DAT$i\_TxDatEnWk_ln$j\_dly/;
      $_ =~ s/ .TxDatFifoWrEn_ln$j     \(PUB_DAT$i\_TxDatFifoWrEn_ln$j/ .TxDatFifoWrEn_ln$j         (PUB_DAT$i\_TxDatFifoWrEn_ln$j\_dly/;
      $_ =~ s/ .TxCmdFifoDlUp_ln$j     \(PUB_DAT$i\_TxCmdFifoDlUp_ln$j/ .TxCmdFifoDlUp_ln$j         (PUB_DAT$i\_TxCmdFifoDlUp_ln$j\_dly/;
    }

    $_ =~ s/.LcdlTxDly1xTgBndl        \(PUB_DAT$i\_LcdlTxDly1xTgBndl \[90:0\] \),/.LcdlTxDly1xTgBndl        (PUB_DAT$i\_LcdlTxDly1xTgBndl_dly [90:0] ),/;

    $_ =~ s/ .LcdlRxDly1xTgBndl        \(PUB_DAT$i\_LcdlRxDly1xTgBndl \[117:0\] \),/ .LcdlRxDly1xTgBndl        (PUB_DAT$i\_LcdlRxDly1xTgBndl_dly [117:0] ),/;

    $_ =~ s/ .VrefDACBndl              \(PUB_DAT$i\_csrVrefDACBndl    \[126:0\] \),/ .VrefDACBndl              (PUB_DAT$i\_csrVrefDACBndl_dly    [126:0] ),/;

    $_ =~ s/ .csrCoreLoopbackMode      \(PUB_DAT$i\_CoreLoopbackMode        \),/ .csrCoreLoopbackMode      (PUB_DAT$i\_CoreLoopbackMode_dly        ),/;

    $_ =~ s/ .csrRxEnTrain             \(PUB_DAT$i\_RxEnTrain               \),/ .csrRxEnTrain             (PUB_DAT$i\_RxEnTrain_dly               ),/;

    $_ =~ s/ .csrPowerDownRcvrDqs      \(PUB_DAT$i\_PowerDownRcvrDqs        \),/ .csrPowerDownRcvrDqs      (PUB_DAT$i\_PowerDownRcvrDqs_dly        ),/;

    $_ =~ s/ .csrPowerDownRcvr         \(PUB_DAT$i\_PowerDownRcvr           \),/ .csrPowerDownRcvr         (PUB_DAT$i\_PowerDownRcvr_dly           ),/;

    $_ =~ s/ .csrRxFifoRdPtrOvr        \(PUB_DAT$i\_csrRxFifoRdPtrOvr       \),/ .csrRxFifoRdPtrOvr        (PUB_DAT$i\_csrRxFifoRdPtrOvr_dly       ),/;

    $_ =~ s/ .csrRxFifoRdPtr           \(PUB_DAT$i\_csrRxFifoRdPtr          \),/ .csrRxFifoRdPtr           (PUB_DAT$i\_csrRxFifoRdPtr_dly          ),/;

    $_ =~ s/ .csrMajorModeDbyte_b0  \(PUB_DAT$i\_csrMajorModeDbyte_b0 \),/ .csrMajorModeDbyte_b0  (PUB_DAT$i\_csrMajorModeDbyte_b0_dly ),/;

    $_ =~ s/ .csrDfeCtrl_b0         \(PUB_DAT$i\_csrDfeCtrl_b0        \),/ .csrDfeCtrl_b0         (PUB_DAT$i\_csrDfeCtrl_b0_dly        ),/;

    $_ =~ s/ .csrMajorModeDbyte_b1  \(PUB_DAT$i\_csrMajorModeDbyte_b1 \),/ .csrMajorModeDbyte_b1  (PUB_DAT$i\_csrMajorModeDbyte_b1_dly ),/;

    $_ =~ s/ .csrDfeCtrl_b1         \(PUB_DAT$i\_csrDfeCtrl_b1        \),/ .csrDfeCtrl_b1         (PUB_DAT$i\_csrDfeCtrl_b1_dly        ),/;
    $_ =~ s/ .DlyTestClkEn             \(PUB_DAT$i\_DlyTestClkEn \[24:0\]\),/ .DlyTestClkEn             (PUB_DAT$i\_DlyTestClkEn_dly [24:0]),/;

    for ($j=0; $j<16; $j++){

        $_ =~ s/ .LcdlCalPhase_n$j    \(PUB_DAT$i\_LcdlCalPhase_n$j\[8:0\] \),/ .LcdlCalPhase_n$j    (PUB_DAT$i\_LcdlCalPhase_n$j\_dly [8:0] ),/;
    }
    $_ =~ s/ .BDLCalPhase              \(PUB_DAT$i\_BDLCalPhase\[6:0\]     \),/ .BDLCalPhase              (PUB_DAT$i\_BDLCalPhase_dly [6:0]     ),/;

    $_ =~ s/ .LcdlCalMode              \(PUB_DAT$i\_LcdlCalMode          \),/ .LcdlCalMode              (PUB_DAT$i\_LcdlCalMode_dly          ),/;

    $_ =~ s/ .LcdlCalEn                \(PUB_DAT$i\_LcdlCalEn            \),/ .LcdlCalEn                (PUB_DAT$i\_LcdlCalEn_dly            ),/;

    $_ =~ s/ .LcdlCalPhaseUpdate       \(PUB_DAT$i\_LcdlCalPhaseUpdate   \),/ .LcdlCalPhaseUpdate       (PUB_DAT$i\_LcdlCalPhaseUpdate_dly   ),/;

    $_ =~ s/ .LcdlCalClkEn             \(PUB_DAT$i\_LcdlCalClkEn         \),/ .LcdlCalClkEn             (PUB_DAT$i\_LcdlCalClkEn_dly         ),/;

    $_ =~ s/ .LcdlCalSampEn            \(PUB_DAT$i\_LcdlCalSampEn        \),/ .LcdlCalSampEn            (PUB_DAT$i\_LcdlCalSampEn_dly        ),/;
  }


   
   print Bf $_;
  }

  print "Generate successfully: dwc_ddrphy_top.v for Gatesim with SDF\n";


