
/** \file 
 * \brief used to set PhyInit inputs statically by the user
 */
#include <string.h>
#include "dwc_ddrphy_phyinit.h"

/**  
 * 1D Message Block 
 */
extern PMU_SMB_DDR3U_1D_t    mb_DDR3U_1D[4];

/**
 *  \addtogroup CustFunc
 *  @{
 */

/** @brief  This function provides a default configuration of PHY.
 * 
 * This function provides a default configuration of PHY. To change the default
 * configuration, the user can edit this file directly or use the 
 * dwc_ddrphy_phyinit_userCustom_overrideUserInput() function. The default
 * values selected below only represent a general case and may not be correct 
 * for every use case.  
 * 
 * @return Void
 */
void dwc_ddrphy_phyinit_setDefault (int Train2D /**< Train2D 1=1D & 2D training enabled, 0=only 1D training. */) {
    
    char *printf_header;
    printf_header = "// [dwc_ddrphy_phyinit_setDefault]";

    dwc_ddrphy_phyinit_print ("%s Start of dwc_ddrphy_phyinit_setDefault()\n", printf_header);


    // ##############################################################
    // userInputBasic - Basic Inputs the user must provide values
    // for detailed descriptions of each field see src/dwc_ddrphy_phyinit_struct.h
    // ##############################################################
    userInputBasic.DramType                 = DDR3;
    userInputBasic.DimmType                 = UDIMM;
    userInputBasic.HardMacroVer             = 3; //default: HardMacro family D 

    userInputBasic.NumDbyte                 = 0x0008;
    userInputBasic.NumActiveDbyteDfi0       = 0x0008;
    userInputBasic.NumAnib                  = 0x000a;
    userInputBasic.NumRank_dfi0             = 0x0001; // 1 Rank
    userInputBasic.NumPStates               = 0x0004; // 1 Pstate
    userInputBasic.Frequency[3]             = 933; 
    userInputBasic.Frequency[2]             = 933; 
    userInputBasic.Frequency[1]             = 933; 
    userInputBasic.Frequency[0]             = 933; // 1866Mbps
    userInputBasic.PllBypass[0]             = 0x0000;
    userInputBasic.PllBypass[1]             = 0x0000;
    userInputBasic.PllBypass[2]             = 0x0000;
    userInputBasic.PllBypass[3]             = 0x0000;
    userInputBasic.DfiFreqRatio[0]          = 0x0001;
    userInputBasic.DfiFreqRatio[1]          = 0x0001;
    userInputBasic.DfiFreqRatio[2]          = 0x0001;
    userInputBasic.DfiFreqRatio[3]          = 0x0001;
    userInputBasic.Dfi1Exists               = 0x0000;
    userInputBasic.DramDataWidth            = 0x0010; //x16

    // ##############################################################
    // userInputAdvnaced (Optional)  
    // Default values will be used if no input provided
    // ##############################################################

    userInputAdvanced.DramByteSwap             = 0x0000; 
    userInputAdvanced.ExtCalResVal             = 0x0000;
    userInputAdvanced.TxSlewRiseDQ[0]          = 0x000f; 
    userInputAdvanced.TxSlewRiseDQ[1]          = 0x000f; 
    userInputAdvanced.TxSlewRiseDQ[2]          = 0x000f; 
    userInputAdvanced.TxSlewRiseDQ[3]          = 0x000f; 
    userInputAdvanced.TxSlewFallDQ[0]          = 0x000f; 
    userInputAdvanced.TxSlewFallDQ[1]          = 0x000f; 
    userInputAdvanced.TxSlewFallDQ[2]          = 0x000f; 
    userInputAdvanced.TxSlewFallDQ[3]          = 0x000f; 
    userInputAdvanced.TxSlewRiseAC             = 0x000f; 
    userInputAdvanced.TxSlewFallAC             = 0x000f; 
    //In DDR3, pull-up and pull-down impedances will be twice the impedance value set in ODTImpedance field
    userInputAdvanced.ODTImpedance[0]          = 60;      
    userInputAdvanced.ODTImpedance[1]          = 60; 
    userInputAdvanced.ODTImpedance[2]          = 60; 
    userInputAdvanced.ODTImpedance[3]          = 60; 
    userInputAdvanced.TxImpedance[0]           = 60; 
    userInputAdvanced.TxImpedance[1]           = 60; 
    userInputAdvanced.TxImpedance[2]           = 60; 
    userInputAdvanced.TxImpedance[3]           = 60;     
    userInputAdvanced.ATxImpedance             = 20;      //with HardMacro family E, ATxImpedance will default to 40 Ohm instead       
    userInputAdvanced.MemAlertEn               = 0x0000;
    userInputAdvanced.MemAlertPUImp            = 0x0005;
    userInputAdvanced.MemAlertVrefLevel        = 0x0029;
    userInputAdvanced.MemAlertSyncBypass       = 0x0000;
    userInputAdvanced.CalInterval              = 0x0009;
    userInputAdvanced.CalOnce                  = 0x0000;

    userInputAdvanced.DisDynAdrTri[0]          = 0x0000;
    userInputAdvanced.DisDynAdrTri[1]          = 0x0000;
    userInputAdvanced.DisDynAdrTri[2]          = 0x0000;
    userInputAdvanced.DisDynAdrTri[3]          = 0x0000;
    userInputAdvanced.Is2Ttiming[0]            = 0x0000;
    userInputAdvanced.Is2Ttiming[1]            = 0x0000;
    userInputAdvanced.Is2Ttiming[2]            = 0x0000;
    userInputAdvanced.Is2Ttiming[3]            = 0x0000;



    // ##############################################################
    // Basic Message Block Variables
    // ##############################################################
    
    uint8_t myps;

    // ##############################################################
    // These are typically invariant across Pstate
    // ##############################################################
    uint8_t MsgMisc              = 0x06; //For fast simulation
    uint8_t Reserved00           = 0x0;  // Set Reserved00[7]   = 1 (If using T28 attenuated receivers)
                                         // Set Reserved00[6:0] = 0 (Reserved; must be programmed to 0)
                                          
    uint8_t HdtCtrl              = 0xff;
    uint8_t CsPresent            = 0x01; // Indicates presence of DRAM at each chip select for PHY. 
                                         // 
                                         // If the bit is set to 1, the CS is connected to DRAM. 
                                         // If the bit is set to 0, the CS is not connected to DRAM.
                                         // 
                                         // Set CsPresent[0]   = 1 (if CS0 is populated with DRAM)
                                         // Set CsPresent[1]   = 1 (if CS1 is populated with DRAM)
                                         // Set CsPresent[2]   = 1 (if CS2 is populated with DRAM)
                                         // Set CsPresent[3]   = 1 (if CS3 is populated with DRAM)
                                         // Set CsPresent[7:4] = 0 (Reserved; must be programmed to 0)
 
    uint8_t PhyVref              = 0x56; //Use Analytical VREF and Compensate for T28 Attenuator, see PHY databook
    uint8_t DFIMRLMargin         = 0x01; //1 is typically good in DDR3
 
    uint8_t AddrMirror           = 0x00; // Set AddrMirror[pstate] if CS[pstate] is mirrored. (typically odd CS are mirroed in DIMMs)
    uint8_t WRODTPAT_RANK0       = 0x01; //When Writing Rank0 : Bits[3:0] should be set to the desired setting of ODT[3:0] to the DRAM
    uint8_t WRODTPAT_RANK1       = 0x02; //When Writing Rank1 : Bits[3:0] should be set to the desired setting of ODT[3:0] to the DRAM
    uint8_t WRODTPAT_RANK2       = 0x04; //When Writing Rank2 : Bits[3:0] should be set to the desired setting of ODT[3:0] to the DRAM
    uint8_t WRODTPAT_RANK3       = 0x08; //When Writing Rank3 : Bits[3:0] should be set to the desired setting of ODT[3:0] to the DRAM
      		  
    uint8_t RDODTPAT_RANK0       = 0x20; //When Reading Rank0 : Bits[7:4] should be set to the desired setting of ODT[3:0] to the DRAM
    uint8_t RDODTPAT_RANK1       = 0x10; //When Reading Rank1 : Bits[7:4] should be set to the desired setting of ODT[3:0] to the DRAM
    uint8_t RDODTPAT_RANK2       = 0x80; //When Reading Rank2 : Bits[7:4] should be set to the desired setting of ODT[3:0] to the DRAM
    uint8_t RDODTPAT_RANK3       = 0x40; //When Reading Rank3 : Bits[7:4] should be set to the desired setting of ODT[3:0] to the DRAM
    // ##############################################################
    // These typically change across Pstate
    // ##############################################################
    
    uint16_t SequenceCtrl[4];
  
    SequenceCtrl[0] = 0x031f; // Training steps to run in PState 0
    SequenceCtrl[1] = 0x021f; // Training steps to run in PState 1
    SequenceCtrl[2] = 0x021f; // Training steps to run in PState 2
    SequenceCtrl[3] = 0x021f; // Training steps to run in PState 3

    uint16_t  mr0[4];     
    uint16_t  mr1[4];     
    uint16_t  mr2[4];     

    mr0[0] = 0x1E14; //1866 : BL= BL8 ONLY, CL = 13, tWR = 14, PCPD-Fast-Exit 
    mr1[0] = 0x0004; //1866 : DLL-Enable, DIC = RZQ/6 , RTTNOM = RZQ/4 , AL=0 				 
    mr2[0] = 0x0020; //1866 : PASR = full-array, CWL = 9, ASR = Manual, SR-TempRange = Normal, RTTWR = disable 
    	
    mr0[1] = 0x0000;
    mr1[1] = 0x0000;
    mr2[1] = 0x0000;
 
    mr0[2] = 0x0000;
    mr1[2] = 0x0000;
    mr2[2] = 0x0000;
 
    mr0[3] = 0x0000;
    mr1[3] = 0x0000;
    mr2[3] = 0x0000;
    
    

    // ##############################################################
    // These are per-pstate Control Words for RCD
    // Please enter the correct values for your configuration
    // ##############################################################
      



    // ##############################################################
    // 95% of users will not need to edit below
    // ##############################################################



    // 1D message block defaults
    for (myps=0; myps<4; myps++) {
      mb_DDR3U_1D[myps].Pstate               = myps;
      mb_DDR3U_1D[myps].SequenceCtrl         = SequenceCtrl[myps];
      mb_DDR3U_1D[myps].PhyConfigOverride    = 0x0;
      mb_DDR3U_1D[myps].HdtCtrl              = HdtCtrl;
      mb_DDR3U_1D[myps].MsgMisc              = MsgMisc;
      mb_DDR3U_1D[myps].Reserved00           = Reserved00;
      mb_DDR3U_1D[myps].DFIMRLMargin         = DFIMRLMargin;
      mb_DDR3U_1D[myps].PhyVref              = PhyVref;
  
      mb_DDR3U_1D[myps].CsPresent            = CsPresent;
      mb_DDR3U_1D[myps].CsPresentD0          = CsPresent;
      mb_DDR3U_1D[myps].CsPresentD1          = 0x0000; //Unused in UDIMM or DRAM-ON-PCB
      mb_DDR3U_1D[myps].AddrMirror           = AddrMirror;
                                                   
      mb_DDR3U_1D[myps].AcsmOdtCtrl0         = WRODTPAT_RANK0 | RDODTPAT_RANK0;
      mb_DDR3U_1D[myps].AcsmOdtCtrl1         = WRODTPAT_RANK1 | RDODTPAT_RANK1;
      mb_DDR3U_1D[myps].AcsmOdtCtrl2         = WRODTPAT_RANK2 | RDODTPAT_RANK2;
      mb_DDR3U_1D[myps].AcsmOdtCtrl3         = WRODTPAT_RANK3 | RDODTPAT_RANK3;
      				                               
      mb_DDR3U_1D[myps].AcsmOdtCtrl4         = 0x0000; //Unused in UDIMM or DRAM-ON-PCB
      mb_DDR3U_1D[myps].AcsmOdtCtrl5         = 0x0000; //Unused in UDIMM or DRAM-ON-PCB
      mb_DDR3U_1D[myps].AcsmOdtCtrl6         = 0x0000; //Unused in UDIMM or DRAM-ON-PCB
      mb_DDR3U_1D[myps].AcsmOdtCtrl7         = 0x0000; //Unused in UDIMM or DRAM-ON-PCB
      mb_DDR3U_1D[myps].EnabledDQs           = (userInputBasic.NumActiveDbyteDfi0+userInputBasic.NumActiveDbyteDfi1)*8;
      mb_DDR3U_1D[myps].PhyCfg               = userInputAdvanced.Is2Ttiming[myps];
      mb_DDR3U_1D[myps].MR0                  = mr0[myps];
      mb_DDR3U_1D[myps].MR1                  = mr1[myps];
      mb_DDR3U_1D[myps].MR2                  = mr2[myps];

      


      } // myps

    // ##############################################################
    // userInputSim - Dram/Dimm Timing Parameters the user must p
    // provide value if applicable
    // ##############################################################
    userInputSim.tDQS2DQ                    = 0;  
    userInputSim.tDQSCK                     = 0;  
    userInputSim.tSTAOFF[0]                 = 0;
    userInputSim.tSTAOFF[1]                 = 0;
    userInputSim.tSTAOFF[2]                 = 0;
    userInputSim.tSTAOFF[3]                 = 0;
    userInputSim.tPDM[0]                    = 0;
    userInputSim.tPDM[1]                    = 0;
    userInputSim.tPDM[2]                    = 0;
    userInputSim.tPDM[3]                    = 0;

    
    dwc_ddrphy_phyinit_print ("%s End of dwc_ddrphy_phyinit_setDefault()\n", printf_header);
}
/** @} */
