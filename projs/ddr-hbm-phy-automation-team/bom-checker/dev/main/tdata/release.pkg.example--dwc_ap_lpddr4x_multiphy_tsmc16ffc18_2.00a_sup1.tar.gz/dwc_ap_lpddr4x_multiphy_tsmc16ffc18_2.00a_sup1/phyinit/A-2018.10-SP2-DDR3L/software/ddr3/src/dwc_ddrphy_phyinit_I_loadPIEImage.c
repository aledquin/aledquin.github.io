/** \file
 * \brief implements Step I of initialization sequence
 *
 * This file contains the implementation of dwc_ddrphy_phyinit_I_initPhyConfig
 * function. 
 *
 *  \addtogroup SrcFunc
 *  @{
 */
#include "dwc_ddrphy_phyinit.h"
/** \brief Loads registers after training
 *
 * This function programs the PHY Initialization Engine (PIE) instructions and
 * the associated registers.  
 * 
 * \return void
 * 
 * Detailed list of registers programmed by this function:
 */
void dwc_ddrphy_phyinit_I_loadPIEImage (int skip_training) {
    
    char *printf_header;
    printf_header = "// [phyinit_I_loadPIEImage]";
    
    dwc_ddrphy_phyinit_cmnt ("%s Start of dwc_ddrphy_phyinit_I_loadPIEImage()\n", printf_header);

    unsigned int pstate; 
    int p_addr;

    dwc_ddrphy_phyinit_cmnt ("\n");
    dwc_ddrphy_phyinit_cmnt ("\n");
    dwc_ddrphy_phyinit_cmnt ("//##############################################################\n");
    dwc_ddrphy_phyinit_cmnt ("//\n");
    dwc_ddrphy_phyinit_cmnt ("// (I) Load PHY Init Engine Image \n");
    dwc_ddrphy_phyinit_cmnt ("// \n");
    dwc_ddrphy_phyinit_cmnt ("// Load the PHY Initialization Engine memory with the provided initialization sequence.\n");
    dwc_ddrphy_phyinit_cmnt ("// See PhyInit App Note for detailed description and function usage\n");
    dwc_ddrphy_phyinit_cmnt ("// \n");
    dwc_ddrphy_phyinit_cmnt ("// \n");
    dwc_ddrphy_phyinit_cmnt ("//##############################################################\n");
    dwc_ddrphy_phyinit_cmnt ("\n");
    dwc_ddrphy_phyinit_cmnt ("\n");
    
    dwc_ddrphy_phyinit_cmnt ("// Enable access to the internal CSRs by setting the MicroContMuxSel CSR to 0. \n");
    dwc_ddrphy_phyinit_cmnt ("// This allows the memory controller unrestricted access to the configuration CSRs. \n");
    dwc_ddrphy_phyinit_userCustom_io_write16((tAPBONLY | csr_MicroContMuxSel_ADDR), 0x0);

    dwc_ddrphy_phyinit_cmnt ("%s Programming PIE Production Code\n", printf_header);

    dwc_ddrphy_phyinit_LoadPieProdCode();

    /**
     * - Registers: Seq0BDLY0, Seq0BDLY1, Seq0BDLY2, Seq0BDLY3
     *   - Program PIE instruction delays 
     *   - Dependencies:
     *     - user_input_basic.Frequency
     */
    // Need delays for 0.5us, 1us, 10us, and 25us.
    uint16_t psCount[4][4];
    float delayScale = 1.00;

    // Calculate the counts to obtain the correct delay for each frequency
    // Need to divide by 4 since the delay value are specified in units of
    // 4 clocks.
    double DfiFrq,dllLock;

    for (pstate=0;pstate<userInputBasic.NumPStates;pstate++) {
      p_addr = pstate << 20;
      DfiFrq = (0.5 * userInputBasic.Frequency[pstate]);
      psCount[pstate][0] = (int)(( 0.5 * 0.25 * DfiFrq * delayScale));
      int LowFreqOpt = 0;
      if ( userInputBasic.Frequency[pstate] < 400 ) LowFreqOpt = 3;
      else if ( userInputBasic.Frequency[pstate] < 533 ) LowFreqOpt = 11;
      psCount[pstate][1] = (int)(( 1.0 * 0.25 * DfiFrq * delayScale)) - LowFreqOpt;;
      psCount[pstate][2] = (int)((10.0 * 0.25 * DfiFrq * delayScale));

      if (DfiFrq>266.5) { dllLock=176; } 
      else if (DfiFrq<=266.5 && DfiFrq>200) { dllLock=132; } 
      else { dllLock=64; }

      psCount[pstate][3] = (int)(0.25 * dllLock);

      dwc_ddrphy_phyinit_cmnt ("%s Pstate=%d,  Memclk=%dMHz, Programming Seq0BDLY0 to 0x%x\n", printf_header, pstate,  userInputBasic.Frequency[pstate], psCount[pstate][0]);
      dwc_ddrphy_phyinit_userCustom_io_write16((p_addr | c0 | tMASTER | csr_Seq0BDLY0_ADDR), psCount[pstate][0]);
      
      dwc_ddrphy_phyinit_cmnt ("%s Pstate=%d,  Memclk=%dMHz, Programming Seq0BDLY1 to 0x%x\n", printf_header, pstate,  userInputBasic.Frequency[pstate], psCount[pstate][1]);
      dwc_ddrphy_phyinit_userCustom_io_write16((p_addr | c0 | tMASTER | csr_Seq0BDLY1_ADDR), psCount[pstate][1]);
      
      dwc_ddrphy_phyinit_cmnt ("%s Pstate=%d,  Memclk=%dMHz, Programming Seq0BDLY2 to 0x%x\n", printf_header, pstate,  userInputBasic.Frequency[pstate], psCount[pstate][2]);
      dwc_ddrphy_phyinit_userCustom_io_write16((p_addr | c0 | tMASTER | csr_Seq0BDLY2_ADDR), psCount[pstate][2]);
      
      dwc_ddrphy_phyinit_cmnt ("%s Pstate=%d,  Memclk=%dMHz, Programming Seq0BDLY3 to 0x%x\n", printf_header, pstate,  userInputBasic.Frequency[pstate], psCount[pstate][3]);
      dwc_ddrphy_phyinit_userCustom_io_write16((p_addr | c0 | tMASTER | csr_Seq0BDLY3_ADDR), psCount[pstate][3]);

    }
    /**
     * - Registers: Seq0BDisableFlag0 Seq0BDisableFlag1 Seq0BDisableFlag2 
     *   Seq0BDisableFlag3 Seq0BDisableFlag4 Seq0BDisableFlag5
     *   - Program PIE Instruction Disable Flags 
     *   - Dependencies:
     *     - user_input_advanced.DisableRetraining
     *     - skip_training
     *     - user_input_basic.Frequency
     */
    dwc_ddrphy_phyinit_userCustom_io_write16((tINITENG | csr_Seq0BDisableFlag0_ADDR), 0x0000);
    dwc_ddrphy_phyinit_userCustom_io_write16((tINITENG | csr_Seq0BDisableFlag1_ADDR), 0x0173);
    dwc_ddrphy_phyinit_userCustom_io_write16((tINITENG | csr_Seq0BDisableFlag2_ADDR), 0x0060);
    dwc_ddrphy_phyinit_userCustom_io_write16((tINITENG | csr_Seq0BDisableFlag3_ADDR), 0x6110);
    dwc_ddrphy_phyinit_userCustom_io_write16((tINITENG | csr_Seq0BDisableFlag4_ADDR), 0x2152);
    dwc_ddrphy_phyinit_userCustom_io_write16((tINITENG | csr_Seq0BDisableFlag5_ADDR), 0xDFBD);
    dwc_ddrphy_phyinit_userCustom_io_write16((tINITENG | csr_Seq0BDisableFlag6_ADDR), 0xffff);
    dwc_ddrphy_phyinit_userCustom_io_write16((tINITENG | csr_Seq0BDisableFlag7_ADDR), 0x6152);






   /// - Register: CalZap
   ///   - Prepare the calibration controller for mission mode.
   ///     Turn on calibration and hold idle until dfi_init_start is asserted sequence is triggered.
    dwc_ddrphy_phyinit_cmnt ("%s Turn on calibration and hold idle until dfi_init_start is asserted sequence is triggered.\n", printf_header);
    dwc_ddrphy_phyinit_userCustom_io_write16((tMASTER | csr_CalZap_ADDR), 0x1);

   /// - Register: CalRate
   ///   - Fields:
   ///     - CalRun
   ///     - CalOnce
   ///     - CalInterval
   ///   - Dependencies 
   ///     - user_input_advanced.CalInterval 
   ///     - user_input_advanced.CalRun
   ///     - user_input_advanced.CalOnce

    int CalRate;
    int CalInterval;
    int CalOnce;

    CalInterval = userInputAdvanced.CalInterval;
    CalOnce = userInputAdvanced.CalOnce;

    CalRate = (0x1 << csr_CalRun_LSB) | (CalOnce << csr_CalOnce_LSB) | (CalInterval << csr_CalInterval_LSB);

    dwc_ddrphy_phyinit_cmnt ("%s Programming CalRate::CalInterval to 0x%x\n", printf_header, CalInterval);
    dwc_ddrphy_phyinit_cmnt ("%s Programming CalRate::CalOnce to 0x%x\n", printf_header, CalOnce);
    dwc_ddrphy_phyinit_cmnt ("%s Programming CalRate::CalRun to 0x%x\n", printf_header, 0x1);

    dwc_ddrphy_phyinit_userCustom_io_write16((tMASTER | csr_CalRate_ADDR), CalRate);

   /**
    * At the end of this function, PHY Clk gating register UcclkHclkEnables is
    * set for mission mode.  Additionally APB access is Isolated by setting 
    * MicroContMuxSel.
    */
    dwc_ddrphy_phyinit_cmnt ("%s Disabling Ucclk (PMU) and Hclk (training hardware)\n", printf_header);
    dwc_ddrphy_phyinit_userCustom_io_write16((tDRTUB | csr_UcclkHclkEnables_ADDR), 0x0);
    
    dwc_ddrphy_phyinit_cmnt ("%s Isolate the APB access from the internal CSRs by setting the MicroContMuxSel CSR to 1. \n", printf_header);
    dwc_ddrphy_phyinit_userCustom_io_write16((tAPBONLY | csr_MicroContMuxSel_ADDR), 0x1);

    dwc_ddrphy_phyinit_cmnt ("%s End of dwc_ddrphy_phyinit_I_loadPIEImage()\n", printf_header);

}
/** @} */
