#!/usr/bin/perl

use strict;
use warnings;
use Getopt::Long;

my %opts;


GetOptions(\%opts,
          "cfg=s",
          "test=s", 
          "dram=s",
          "dimm=s",
          "lp4x_mode=s",
          "skip_train=s",
          "train2d=s",
          "freq0=s",
          "freq1=s",
          "freq2=s",
          "freq3=s",
          "freq_ratio0=s",
          "freq_ratio1=s",
          "freq_ratio2=s",
          "freq_ratio3=s",
          "pll_bypass0=s",
          "pll_bypass1=s",
          "pll_bypass2=s",
          "pll_bypass3=s",
          "rank=s",
          "pstates=s",
          "seqCtrl=s",
          "hdtCtrl=s",
          "dfi_mode=s",
          "rdbi0=s",
          "rdbi1=s",
          "rdbi2=s",
          "rdbi3=s",
          "help"
           ) || HelpUser();

HelpUser() if (defined $opts{help});

#===================================================================================================
sub HelpUser {
#===================================================================================================
  print "
usage:  gen_override_c.pl 
        -cfg=<cfg_name>         : Hardware configuration name, such as: cfg=ac12d9ch1.              
        -test=<test_name>       : Test case name. Tests are defined as a directories under the /ctb/tc.  Required argument.
        -dram=<dram tye>        : SDRAM Standard name. Currently, either ddr4 or lpddr4 or none (for ATE testing).
        -dimm=<dimm type>       : DIMM type: udimm, rdimm, lrdimm.
        -lp4x_mode=<0|1>        : Enable/Disable lp4x mode
        -skip_train=<0|1|2>     : 0 - training, 1 - skip training, 2 - devInit.
        -train2d=<0|1>          : Execute 2d training when training enabled. Default don't execute 2d training
        -freq0=<freq of P0>     : DRAM working frequency of Pstate 0, unit MHz. Default: 800
        -freq1=<freq of P0>     : DRAM working frequency of Pstate 1, unit MHz. Default: 800
        -freq2=<freq of P0>     : DRAM working frequency of Pstate 2, unit MHz. Default: 800
        -freq3=<freq of P0>     : DRAM working frequency of Pstate 3, unit MHz. Default: 800
        -freq_ratio0=<0|1|2>    : Freq ratio of Pstate0, 0 - 1:1, 1 - 1:2, 2 - 1:4. Default: 0 - 1:1
        -freq_ratio1=<0|1|2>    : Freq ratio of Pstate1, 0 - 1:1, 1 - 1:2, 2 - 1:4. Default: 0 - 1:1
        -freq_ratio2=<0|1|2>    : Freq ratio of Pstate2, 0 - 1:1, 1 - 1:2, 2 - 1:4. Default: 0 - 1:1
        -freq_ratio3=<0|1|2>    : Freq ratio of Pstate3, 0 - 1:1, 1 - 1:2, 2 - 1:4. Default: 0 - 1:1        
        -pll_bypass0=<0|1>       : Pclk come from bypass_clk for Pstate0
        -pll_bypass1=<0|1>       : Pclk come from bypass_clk for Pstate1
        -pll_bypass2=<0|1>       : Pclk come from bypass_clk for Pstate2
        -pll_bypass3=<0|1>       : Pclk come from bypass_clk for Pstate3
        -rank=<1|2|4>           : Total rank number in one channel.
        -pstates=<1|2|3|4>      : Total number of PStates.
        -seqCtrl=<SequenceCtrl> : Hex, control which training steps are executed. Default : 1
        -hdtCtrl=<HdtCtrl>      : Hex, control the mailbox debug messages verbosity, default : c8
        -dfi_mode=<1|3|5>       : dfi_mode configuration name, only apply to LPDDR, such as: dfi_mode=5
        -rdbi0=<0|1>            : read dbi for Pstate0
        -rdbi1=<0|1>            : read dbi for Pstate1
        -rdbi2=<0|1>            : read dbi for Pstate2
        -rdbi3=<0|1>            : read dbi for Pstate3
        -help                   : print help message.
";
  exit 1;
}

#-----------------------------------------------------------------------------------------------------
# Copy phyinit to .fw
#-----------------------------------------------------------------------------------------------------
my $phyinit_dir;
if ($ENV{release}==0) {
  $phyinit_dir = "$ENV{CTB_HOME}/../build/c/init" ;
} elsif ($ENV{release}==1) {
  $phyinit_dir = "$ENV{CTB_PHYINIT_DIR}";
} elsif ($ENV{release}==2) {
  $phyinit_dir = "$ENV{CTB_PHYINIT_DIR}";
}

system("rm -rf .fw");
system("cp -rf $phyinit_dir .fw");
system("chmod -R 775 .fw");

#-----------------------------------------------------------------------------------------------------
# Generate input file(.result) of postprocess.pl
#-----------------------------------------------------------------------------------------------------
system("rm -f ./.result;");
system("touch ./.result; chmod 775 ./.result");
open(my $FH,'>:encoding(UTF-8)',"./.result")or die "Could not open file '.result"; 

my $head = "set_activity_parameter PHYInitializationsettings";
my $tmp;

# Anib num/DByte num/DFI1 exits
if($opts{cfg} =~ /ac(\d+)d(\d+)ch(\d+)/){ 
  print $FH "$head userInputBasic_NumAnib $1;\n"; 
  print $FH "$head userInputBasic_NumDbyte $2;\n";
  $tmp = $3-1;
  print $FH "$head userInputBasic_Dfi1Exists $tmp;\n";
} else {
   die "[gen_override_c: Illegal cfg=$opts{cfg}]";
}

if($3==1){    #ch1
  #if(($2 > 8) && ($opts{dimm} ne "lrdimm") ) {  #CTB limitaion, ddr4 udimm doesn't support DByte number 9
  #  print $FH "$head userInputBasic_NumActiveDbyteDfi0 8\n";
  #} else{
    print $FH "$head userInputBasic_NumActiveDbyteDfi0 $2;\n"
  #}
} else {      #ch2
  if($opts{dram} eq "lpddr4" || $opts{dram} eq "lpddr3"){
    $tmp = $2/2;
    if($opts{dfi_mode} == 5){ #DFI0 override DFI1
      print $FH "$head userInputBasic_NumActiveDbyteDfi0 $2;\n";
    } elsif($opts{dfi_mode} == 1){ #DFI1 disabled
      print $FH "$head userInputBasic_NumActiveDbyteDfi0 $tmp;\n";
    }else{     #dfi_mode=3
      print $FH "$head userInputBasic_NumActiveDbyteDfi0 $tmp;\n";
      print $FH "$head userInputBasic_NumActiveDbyteDfi1 $tmp;\n";
    }
  } else {
    print $FH "$head userInputBasic_NumActiveDbyteDfi0 $2;\n";
  }
}

# DramDataWidth
if($opts{dram} eq "lpddr4"){
  print $FH "$head userInputBasic_DramDataWidth 16;\n";
} elsif($opts{dram} eq "lpddr3"){
  print $FH "$head userInputBasic_DramDataWidth 32;\n";
} elsif($opts{dimm} eq "lrdimm"){
  print $FH "$head userInputBasic_DramDataWidth 4;\n";
}else{
  print $FH "$head userInputBasic_DramDataWidth 8;\n";
}

# Dram type, Dimm type, Lp4x mode
$tmp = uc($opts{dram}); 
print $FH "$head userInputBasic_DramType $tmp;\n";
$tmp = uc($opts{dimm});
print $FH "$head userInputBasic_DimmType $tmp;\n";
if ($opts{dram} eq "lpddr4"){
  print $FH "$head userInputBasic_Lp4xMode $opts{lp4x_mode};\n";
}

# Train2d
print $FH "$head userInputBasic_Train2D $opts{train2d};\n";

# Rank
print $FH "$head userInputBasic_NumRank_dfi0 $opts{rank};\n";
if($opts{dfi_mode} == 3 && $3 ==2){ # DFI1 exists and enabled
  print $FH "$head userInputBasic_NumRank_dfi1 $opts{rank};\n";
} else{
  print $FH "$head userInputBasic_NumRank_dfi1 0;\n";
}

# Pstats number
print $FH "$head userInputBasic_NumPStates $opts{pstates};\n";

# Frequency
my @freqs = ($opts{freq0}, $opts{freq1}, $opts{freq2}, $opts{freq3});
foreach my $i(0..$opts{pstates}-1){
print $FH "$head userInputBasic_Frequency$i $freqs[$i];\n";
}

# Freq_ratio
my @freq_ratios = ($opts{freq_ratio0}, $opts{freq_ratio1}, $opts{freq_ratio2}, $opts{freq_ratio3});
foreach my $i(0..$opts{pstates}-1){
print $FH "$head userInputBasic_DfiFreqRatio$i $freq_ratios[$i];\n";
}

# PllBypass
my @pll_bypass = ($opts{pll_bypass0}, $opts{pll_bypass1}, $opts{pll_bypass2}, $opts{pll_bypass3});
foreach my $i(0..$opts{pstates}-1){
 print $FH "$head userInputBasic_PllBypass$i $pll_bypass[$i];\n";
} 

#rdbi
my @rdbi = ($opts{rdbi0}, $opts{rdbi1}, $opts{rdbi2}, $opts{rdbi3});
foreach my $i(0..$opts{pstates}-1){
print $FH "$head userInputBasic_RDBI$i $rdbi[$i];\n";
}

# SeqeuencCtrl
print $FH "$head mb_SequenceCtrl $opts{seqCtrl};\n";

# HdtCtrl
print $FH "$head mb_HdtCtrl $opts{hdtCtrl};\n";

# DfiMode
if($opts{dram} =~ /lpddr/){
  print $FH "$head userInputBasic_DfiMode $opts{dfi_mode};\n";
}  

# csMode
# only apply to RDIMM/LRDIM
# 0: Direct DualCS mode
# 1: Direct QuadCS mode
# 3: Encoded QuadCS mode
if($opts{dimm} eq "rdimm" || $opts{dimm} eq "lrdimm") {
  if($opts{rank} <3) {
    print $FH "$head csMode 0";
  } else{
    print $FH "$head csMode 1";
  }
}



close $FH;

