/** \file 
 * \brief conditionally sets messageBlock variables
 * \addtogroup SrcFunc
 * @{
 */
#include <string.h>
#include "dwc_ddrphy_phyinit.h"


/** @brief Set messageBlock variable only if not set by user
 *
 * this function works same as dwc_ddrphy_phyinit_setMb(). It is used by
 * dwc_ddrphy_phyinit_calcMb() to set calculated messageBlock variables only
 * when the user has not directly programmed them. If
 * dwc_ddrphy_phyinit_setDefault() and
 * dwc_ddrphy_phyinit_userCustom_overrideUserInput() are used to program a
 * particular variable, this function will skip setting the value.
 *
 * @param[in]   ps      integer between 0-3. Specifies the PState for which the messageBlock field should be set.
 * @param[in]   field   A string representing the messageBlock field to be programed. 
 * @param[in]   value   filed value
 * @param[in]   Train2D determined if the field should be set on 2D or 1D messageBlock.
 *
 * @return 0 on success or if field was set in dwc_ddrphy_phyinit_setDefault() or
 * dwc_ddrphy_phyinit_userCustom_overrideUserInput(). On error  returns the following values based on
 * error:
 * - -1 : message block field specified by the input \c field string is not
 * found in the message block data structure.
 * - -2 : when DramType does not support 2D training but a 2D training field is
 * programmed.
 * - -3 : Train2D inputs is neither 1 or 0.
 */
int dwc_ddrphy_phyinit_softSetMb (int ps, char *field, int value, int Train2D) {

    char *printf_header;
    printf_header = "// [dwc_ddrphy_phyinit_softSetMb]";

    if (Train2D == 0) {
      if ( strcmp(field, "Reserved00") == 0) {
        if(shdw_DDR3U_1D[ps].Reserved00 == 0) {
          mb_DDR3U_1D[ps].Reserved00 = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].Reserved00);
        }
      }
      else if ( strcmp(field, "MsgMisc") == 0) {
        if(shdw_DDR3U_1D[ps].MsgMisc == 0) {
          mb_DDR3U_1D[ps].MsgMisc = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].MsgMisc);
        }
      }
      else if ( strcmp(field, "Pstate") == 0) {
        if(shdw_DDR3U_1D[ps].Pstate == 0) {
          mb_DDR3U_1D[ps].Pstate = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].Pstate);
        }
      }
      else if ( strcmp(field, "PllBypassEn") == 0) {
        if(shdw_DDR3U_1D[ps].PllBypassEn == 0) {
          mb_DDR3U_1D[ps].PllBypassEn = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].PllBypassEn);
        }
      }
      else if ( strcmp(field, "DRAMFreq") == 0) {
        if(shdw_DDR3U_1D[ps].DRAMFreq == 0) {
          mb_DDR3U_1D[ps].DRAMFreq = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].DRAMFreq);
        }
      }
      else if ( strcmp(field, "DfiFreqRatio") == 0) {
        if(shdw_DDR3U_1D[ps].DfiFreqRatio == 0) {
          mb_DDR3U_1D[ps].DfiFreqRatio = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].DfiFreqRatio);
        }
      }
      else if ( strcmp(field, "BPZNResVal") == 0) {
        if(shdw_DDR3U_1D[ps].BPZNResVal == 0) {
          mb_DDR3U_1D[ps].BPZNResVal = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].BPZNResVal);
        }
      }
      else if ( strcmp(field, "PhyOdtImpedance") == 0) {
        if(shdw_DDR3U_1D[ps].PhyOdtImpedance == 0) {
          mb_DDR3U_1D[ps].PhyOdtImpedance = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].PhyOdtImpedance);
        }
      }
      else if ( strcmp(field, "PhyDrvImpedance") == 0) {
        if(shdw_DDR3U_1D[ps].PhyDrvImpedance == 0) {
          mb_DDR3U_1D[ps].PhyDrvImpedance = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].PhyDrvImpedance);
        }
      }
      else if ( strcmp(field, "PhyVref") == 0) {
        if(shdw_DDR3U_1D[ps].PhyVref == 0) {
          mb_DDR3U_1D[ps].PhyVref = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].PhyVref);
        }
      }
      else if ( strcmp(field, "DramType") == 0) {
        if(shdw_DDR3U_1D[ps].DramType == 0) {
          mb_DDR3U_1D[ps].DramType = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].DramType);
        }
      }
      else if ( strcmp(field, "DisabledDbyte") == 0) {
        if(shdw_DDR3U_1D[ps].DisabledDbyte == 0) {
          mb_DDR3U_1D[ps].DisabledDbyte = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].DisabledDbyte);
        }
      }
      else if ( strcmp(field, "EnabledDQs") == 0) {
        if(shdw_DDR3U_1D[ps].EnabledDQs == 0) {
          mb_DDR3U_1D[ps].EnabledDQs = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].EnabledDQs);
        }
      }
      else if ( strcmp(field, "CsPresent") == 0) {
        if(shdw_DDR3U_1D[ps].CsPresent == 0) {
          mb_DDR3U_1D[ps].CsPresent = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].CsPresent);
        }
      }
      else if ( strcmp(field, "CsPresentD0") == 0) {
        if(shdw_DDR3U_1D[ps].CsPresentD0 == 0) {
          mb_DDR3U_1D[ps].CsPresentD0 = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].CsPresentD0);
        }
      }
      else if ( strcmp(field, "CsPresentD1") == 0) {
        if(shdw_DDR3U_1D[ps].CsPresentD1 == 0) {
          mb_DDR3U_1D[ps].CsPresentD1 = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].CsPresentD1);
        }
      }
      else if ( strcmp(field, "AddrMirror") == 0) {
        if(shdw_DDR3U_1D[ps].AddrMirror == 0) {
          mb_DDR3U_1D[ps].AddrMirror = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].AddrMirror);
        }
      }
      else if ( strcmp(field, "PhyCfg") == 0) {
        if(shdw_DDR3U_1D[ps].PhyCfg == 0) {
          mb_DDR3U_1D[ps].PhyCfg = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].PhyCfg);
        }
      }
      else if ( strcmp(field, "SequenceCtrl") == 0) {
        if(shdw_DDR3U_1D[ps].SequenceCtrl == 0) {
          mb_DDR3U_1D[ps].SequenceCtrl = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].SequenceCtrl);
        }
      }
      else if ( strcmp(field, "HdtCtrl") == 0) {
        if(shdw_DDR3U_1D[ps].HdtCtrl == 0) {
          mb_DDR3U_1D[ps].HdtCtrl = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].HdtCtrl);
        }
      }
      else if ( strcmp(field, "Share2DVrefResult") == 0) {
        if(shdw_DDR3U_1D[ps].Share2DVrefResult == 0) {
          mb_DDR3U_1D[ps].Share2DVrefResult = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].Share2DVrefResult);
        }
      }
      else if ( strcmp(field, "Reserved1E") == 0) {
        if(shdw_DDR3U_1D[ps].Reserved1E == 0) {
          mb_DDR3U_1D[ps].Reserved1E = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].Reserved1E);
        }
      }
      else if ( strcmp(field, "PhyConfigOverride") == 0) {
        if(shdw_DDR3U_1D[ps].PhyConfigOverride == 0) {
          mb_DDR3U_1D[ps].PhyConfigOverride = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].PhyConfigOverride);
        }
      }
      else if ( strcmp(field, "DFIMRLMargin") == 0) {
        if(shdw_DDR3U_1D[ps].DFIMRLMargin == 0) {
          mb_DDR3U_1D[ps].DFIMRLMargin = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].DFIMRLMargin);
        }
      }
      else if ( strcmp(field, "MR0") == 0) {
        if(shdw_DDR3U_1D[ps].MR0 == 0) {
          mb_DDR3U_1D[ps].MR0 = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].MR0);
        }
      }
      else if ( strcmp(field, "MR1") == 0) {
        if(shdw_DDR3U_1D[ps].MR1 == 0) {
          mb_DDR3U_1D[ps].MR1 = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].MR1);
        }
      }
      else if ( strcmp(field, "MR2") == 0) {
        if(shdw_DDR3U_1D[ps].MR2 == 0) {
          mb_DDR3U_1D[ps].MR2 = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].MR2);
        }
      }
      else if ( strcmp(field, "AcsmOdtCtrl0") == 0) {
        if(shdw_DDR3U_1D[ps].AcsmOdtCtrl0 == 0) {
          mb_DDR3U_1D[ps].AcsmOdtCtrl0 = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].AcsmOdtCtrl0);
        }
      }
      else if ( strcmp(field, "AcsmOdtCtrl1") == 0) {
        if(shdw_DDR3U_1D[ps].AcsmOdtCtrl1 == 0) {
          mb_DDR3U_1D[ps].AcsmOdtCtrl1 = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].AcsmOdtCtrl1);
        }
      }
      else if ( strcmp(field, "AcsmOdtCtrl2") == 0) {
        if(shdw_DDR3U_1D[ps].AcsmOdtCtrl2 == 0) {
          mb_DDR3U_1D[ps].AcsmOdtCtrl2 = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].AcsmOdtCtrl2);
        }
      }
      else if ( strcmp(field, "AcsmOdtCtrl3") == 0) {
        if(shdw_DDR3U_1D[ps].AcsmOdtCtrl3 == 0) {
          mb_DDR3U_1D[ps].AcsmOdtCtrl3 = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].AcsmOdtCtrl3);
        }
      }
      else if ( strcmp(field, "AcsmOdtCtrl4") == 0) {
        if(shdw_DDR3U_1D[ps].AcsmOdtCtrl4 == 0) {
          mb_DDR3U_1D[ps].AcsmOdtCtrl4 = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].AcsmOdtCtrl4);
        }
      }
      else if ( strcmp(field, "AcsmOdtCtrl5") == 0) {
        if(shdw_DDR3U_1D[ps].AcsmOdtCtrl5 == 0) {
          mb_DDR3U_1D[ps].AcsmOdtCtrl5 = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].AcsmOdtCtrl5);
        }
      }
      else if ( strcmp(field, "AcsmOdtCtrl6") == 0) {
        if(shdw_DDR3U_1D[ps].AcsmOdtCtrl6 == 0) {
          mb_DDR3U_1D[ps].AcsmOdtCtrl6 = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].AcsmOdtCtrl6);
        }
      }
      else if ( strcmp(field, "AcsmOdtCtrl7") == 0) {
        if(shdw_DDR3U_1D[ps].AcsmOdtCtrl7 == 0) {
          mb_DDR3U_1D[ps].AcsmOdtCtrl7 = value;
          dwc_ddrphy_phyinit_cmnt ("%s Setting mb_DDR3U_%dD[%d].%s to 0x%x\n", printf_header, 1, ps, field, value);
        }
        else {
          dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_%dD[%d].%s override to 0x%x\n", printf_header, 1, ps, field, mb_DDR3U_1D[ps].AcsmOdtCtrl7);
        }
      }
      else {
        dwc_ddrphy_phyinit_assert(0,"%s unknown message block field name '%s', Train2D=%d\n", printf_header, field,Train2D);
        return -1;
      }
    }
    else if (Train2D == 1) {
      dwc_ddrphy_phyinit_assert(0,"%s 2D Training is not supported for DDR3!\n", printf_header);
      return -2;
    }
    else {
      dwc_ddrphy_phyinit_assert(0,"%s invalid value for Train2D=%d\n", printf_header, Train2D);
      return -3;
    }

    return 0;
}
/** @} */
