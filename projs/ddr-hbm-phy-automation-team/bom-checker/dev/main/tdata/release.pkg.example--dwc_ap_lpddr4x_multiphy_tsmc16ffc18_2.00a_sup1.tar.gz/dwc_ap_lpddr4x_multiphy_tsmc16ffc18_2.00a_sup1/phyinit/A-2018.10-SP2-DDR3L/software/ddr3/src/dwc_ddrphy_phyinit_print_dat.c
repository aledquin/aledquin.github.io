/** \file 
 * \brief prints PhyInit and messageBlock data structures
 *  \addtogroup SrcFunc
 *  @{
 */
#include "dwc_ddrphy_phyinit.h"


/** @brief prints PhyInit and messageBlock data structures
 * 
 * This function prints the content of PhyInit data structures and messageBlock
 * to output for debug purpose.
 *
 * @returns void
 */
void dwc_ddrphy_phyinit_print_dat () {

    char *printf_header;
    printf_header = "// [phyinit_print_dat]";

    dwc_ddrphy_phyinit_cmnt ("%s // ####################################################\n", printf_header);
    dwc_ddrphy_phyinit_cmnt ("%s // \n", printf_header);
    dwc_ddrphy_phyinit_cmnt ("%s // Printing Runtime input values\n", printf_header);
    dwc_ddrphy_phyinit_cmnt ("%s // \n", printf_header);
    dwc_ddrphy_phyinit_cmnt ("%s // ####################################################\n", printf_header);
    
    dwc_ddrphy_phyinit_cmnt ("%s runtimeConfig.skip_training = %d\n", printf_header, runtimeConfig.skip_train);
    dwc_ddrphy_phyinit_cmnt ("%s runtimeConfig.Train2D       = %d\n", printf_header, runtimeConfig.Train2D);
    dwc_ddrphy_phyinit_cmnt ("%s runtimeConfig.debug         = %d\n", printf_header, runtimeConfig.debug);
    dwc_ddrphy_phyinit_cmnt ("%s runtimeConfig.RetEn         = %d\n", printf_header, runtimeConfig.RetEn);
 
    dwc_ddrphy_phyinit_cmnt ("%s // ####################################################\n", printf_header);
    dwc_ddrphy_phyinit_cmnt ("%s // \n", printf_header);
    dwc_ddrphy_phyinit_cmnt ("%s // Printing values in user input structure\n", printf_header);
    dwc_ddrphy_phyinit_cmnt ("%s // \n", printf_header);
    dwc_ddrphy_phyinit_cmnt ("%s // ####################################################\n", printf_header);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.Frequency[0] = %d\n", printf_header, userInputBasic.Frequency[0]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.Frequency[1] = %d\n", printf_header, userInputBasic.Frequency[1]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.Frequency[2] = %d\n", printf_header, userInputBasic.Frequency[2]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.Frequency[3] = %d\n", printf_header, userInputBasic.Frequency[3]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.NumRank_dfi0 = %d\n", printf_header, userInputBasic.NumRank_dfi0);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.ReadDBIEnable[0] = %d\n", printf_header, userInputBasic.ReadDBIEnable[0]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.ReadDBIEnable[1] = %d\n", printf_header, userInputBasic.ReadDBIEnable[1]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.ReadDBIEnable[2] = %d\n", printf_header, userInputBasic.ReadDBIEnable[2]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.ReadDBIEnable[3] = %d\n", printf_header, userInputBasic.ReadDBIEnable[3]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.Lp4xMode = %d\n", printf_header, userInputBasic.Lp4xMode);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.DimmType = %d\n", printf_header, userInputBasic.DimmType);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.DfiMode = %d\n", printf_header, userInputBasic.DfiMode);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.DramType = %d\n", printf_header, userInputBasic.DramType);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.HardMacroVer = %d\n", printf_header, userInputBasic.HardMacroVer);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.DfiFreqRatio[0] = %d\n", printf_header, userInputBasic.DfiFreqRatio[0]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.DfiFreqRatio[1] = %d\n", printf_header, userInputBasic.DfiFreqRatio[1]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.DfiFreqRatio[2] = %d\n", printf_header, userInputBasic.DfiFreqRatio[2]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.DfiFreqRatio[3] = %d\n", printf_header, userInputBasic.DfiFreqRatio[3]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.NumAnib = %d\n", printf_header, userInputBasic.NumAnib);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.NumDbyte = %d\n", printf_header, userInputBasic.NumDbyte);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.DramDataWidth = %d\n", printf_header, userInputBasic.DramDataWidth);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.PllBypass[0] = %d\n", printf_header, userInputBasic.PllBypass[0]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.PllBypass[1] = %d\n", printf_header, userInputBasic.PllBypass[1]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.PllBypass[2] = %d\n", printf_header, userInputBasic.PllBypass[2]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.PllBypass[3] = %d\n", printf_header, userInputBasic.PllBypass[3]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.Dfi1Exists = %d\n", printf_header, userInputBasic.Dfi1Exists);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.Train2D = %d\n", printf_header, userInputBasic.Train2D);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.NumRank_dfi1 = %d\n", printf_header, userInputBasic.NumRank_dfi1);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.NumActiveDbyteDfi0 = %d\n", printf_header, userInputBasic.NumActiveDbyteDfi0);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.NumPStates = %d\n", printf_header, userInputBasic.NumPStates);
    dwc_ddrphy_phyinit_cmnt ("%s userInputBasic.NumActiveDbyteDfi1 = %d\n", printf_header, userInputBasic.NumActiveDbyteDfi1);

    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.DisDynAdrTri[0] = %d\n", printf_header, userInputAdvanced.DisDynAdrTri[0]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.DisDynAdrTri[1] = %d\n", printf_header, userInputAdvanced.DisDynAdrTri[1]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.DisDynAdrTri[2] = %d\n", printf_header, userInputAdvanced.DisDynAdrTri[2]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.DisDynAdrTri[3] = %d\n", printf_header, userInputAdvanced.DisDynAdrTri[3]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.SnpsUmctlF0RC5x[0] = %d\n", printf_header, userInputAdvanced.SnpsUmctlF0RC5x[0]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.SnpsUmctlF0RC5x[1] = %d\n", printf_header, userInputAdvanced.SnpsUmctlF0RC5x[1]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.SnpsUmctlF0RC5x[2] = %d\n", printf_header, userInputAdvanced.SnpsUmctlF0RC5x[2]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.SnpsUmctlF0RC5x[3] = %d\n", printf_header, userInputAdvanced.SnpsUmctlF0RC5x[3]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.MemAlertEn = %d\n", printf_header, userInputAdvanced.MemAlertEn);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.EnableHighClkSkewFix = %d\n", printf_header, userInputAdvanced.EnableHighClkSkewFix);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.DramByteSwap = %d\n", printf_header, userInputAdvanced.DramByteSwap);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.ExtCalResVal = %d\n", printf_header, userInputAdvanced.ExtCalResVal);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.TxSlewRiseDQ[0] = %d\n", printf_header, userInputAdvanced.TxSlewRiseDQ[0]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.TxSlewRiseDQ[1] = %d\n", printf_header, userInputAdvanced.TxSlewRiseDQ[1]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.TxSlewRiseDQ[2] = %d\n", printf_header, userInputAdvanced.TxSlewRiseDQ[2]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.TxSlewRiseDQ[3] = %d\n", printf_header, userInputAdvanced.TxSlewRiseDQ[3]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.D4TxPreambleLength[0] = %d\n", printf_header, userInputAdvanced.D4TxPreambleLength[0]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.D4TxPreambleLength[1] = %d\n", printf_header, userInputAdvanced.D4TxPreambleLength[1]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.D4TxPreambleLength[2] = %d\n", printf_header, userInputAdvanced.D4TxPreambleLength[2]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.D4TxPreambleLength[3] = %d\n", printf_header, userInputAdvanced.D4TxPreambleLength[3]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.RxEnBackOff = %d\n", printf_header, userInputAdvanced.RxEnBackOff);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.D4RxPreambleLength[0] = %d\n", printf_header, userInputAdvanced.D4RxPreambleLength[0]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.D4RxPreambleLength[1] = %d\n", printf_header, userInputAdvanced.D4RxPreambleLength[1]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.D4RxPreambleLength[2] = %d\n", printf_header, userInputAdvanced.D4RxPreambleLength[2]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.D4RxPreambleLength[3] = %d\n", printf_header, userInputAdvanced.D4RxPreambleLength[3]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.TxSlewFallDQ[0] = %d\n", printf_header, userInputAdvanced.TxSlewFallDQ[0]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.TxSlewFallDQ[1] = %d\n", printf_header, userInputAdvanced.TxSlewFallDQ[1]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.TxSlewFallDQ[2] = %d\n", printf_header, userInputAdvanced.TxSlewFallDQ[2]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.TxSlewFallDQ[3] = %d\n", printf_header, userInputAdvanced.TxSlewFallDQ[3]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.CalOnce = %d\n", printf_header, userInputAdvanced.CalOnce);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.PhyMstrMaxReqToAck[0] = %d\n", printf_header, userInputAdvanced.PhyMstrMaxReqToAck[0]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.PhyMstrMaxReqToAck[1] = %d\n", printf_header, userInputAdvanced.PhyMstrMaxReqToAck[1]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.PhyMstrMaxReqToAck[2] = %d\n", printf_header, userInputAdvanced.PhyMstrMaxReqToAck[2]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.PhyMstrMaxReqToAck[3] = %d\n", printf_header, userInputAdvanced.PhyMstrMaxReqToAck[3]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.DisableUnusedAddrLns = %d\n", printf_header, userInputAdvanced.DisableUnusedAddrLns);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.TxSlewFallAC = %d\n", printf_header, userInputAdvanced.TxSlewFallAC);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.ATxImpedance = %d\n", printf_header, userInputAdvanced.ATxImpedance);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.PhyInitSequenceNum = %d\n", printf_header, userInputAdvanced.PhyInitSequenceNum);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.Is2Ttiming[0] = %d\n", printf_header, userInputAdvanced.Is2Ttiming[0]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.Is2Ttiming[1] = %d\n", printf_header, userInputAdvanced.Is2Ttiming[1]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.Is2Ttiming[2] = %d\n", printf_header, userInputAdvanced.Is2Ttiming[2]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.Is2Ttiming[3] = %d\n", printf_header, userInputAdvanced.Is2Ttiming[3]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.MemAlertVrefLevel = %d\n", printf_header, userInputAdvanced.MemAlertVrefLevel);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.PhyMstrTrainInterval[0] = %d\n", printf_header, userInputAdvanced.PhyMstrTrainInterval[0]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.PhyMstrTrainInterval[1] = %d\n", printf_header, userInputAdvanced.PhyMstrTrainInterval[1]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.PhyMstrTrainInterval[2] = %d\n", printf_header, userInputAdvanced.PhyMstrTrainInterval[2]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.PhyMstrTrainInterval[3] = %d\n", printf_header, userInputAdvanced.PhyMstrTrainInterval[3]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.SnpsUmctlOpt = %d\n", printf_header, userInputAdvanced.SnpsUmctlOpt);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.CalInterval = %d\n", printf_header, userInputAdvanced.CalInterval);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.WDQSExt = %d\n", printf_header, userInputAdvanced.WDQSExt);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.MemAlertPUImp = %d\n", printf_header, userInputAdvanced.MemAlertPUImp);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.ODTImpedance[0] = %d\n", printf_header, userInputAdvanced.ODTImpedance[0]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.ODTImpedance[1] = %d\n", printf_header, userInputAdvanced.ODTImpedance[1]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.ODTImpedance[2] = %d\n", printf_header, userInputAdvanced.ODTImpedance[2]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.ODTImpedance[3] = %d\n", printf_header, userInputAdvanced.ODTImpedance[3]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.TxSlewRiseAC = %d\n", printf_header, userInputAdvanced.TxSlewRiseAC);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.TrainSequenceCtrl = %d\n", printf_header, userInputAdvanced.TrainSequenceCtrl);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.MemAlertSyncBypass = %d\n", printf_header, userInputAdvanced.MemAlertSyncBypass);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.TxImpedance[0] = %d\n", printf_header, userInputAdvanced.TxImpedance[0]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.TxImpedance[1] = %d\n", printf_header, userInputAdvanced.TxImpedance[1]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.TxImpedance[2] = %d\n", printf_header, userInputAdvanced.TxImpedance[2]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputAdvanced.TxImpedance[3] = %d\n", printf_header, userInputAdvanced.TxImpedance[3]);

    dwc_ddrphy_phyinit_cmnt ("%s userInputSim.tDQS2DQ    = %d\n", printf_header, userInputSim.tDQS2DQ);
    dwc_ddrphy_phyinit_cmnt ("%s userInputSim.tDQSCK     = %d\n", printf_header, userInputSim.tDQSCK);
    dwc_ddrphy_phyinit_cmnt ("%s userInputSim.tSTAOFF[0] = %d\n", printf_header, userInputSim.tSTAOFF[0]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputSim.tSTAOFF[1] = %d\n", printf_header, userInputSim.tSTAOFF[1]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputSim.tSTAOFF[2] = %d\n", printf_header, userInputSim.tSTAOFF[2]);
    dwc_ddrphy_phyinit_cmnt ("%s userInputSim.tSTAOFF[3] = %d\n", printf_header, userInputSim.tSTAOFF[3]);

    uint8_t ps;
    for (ps=0; ps<userInputBasic.NumPStates; ps++) {
        dwc_ddrphy_phyinit_cmnt ("%s // ####################################################\n", printf_header);
        dwc_ddrphy_phyinit_cmnt ("%s // \n", printf_header);
        dwc_ddrphy_phyinit_cmnt ("%s // Printing values of 1D message block input/inout fields, PState=%d\n", printf_header, ps);
        dwc_ddrphy_phyinit_cmnt ("%s // \n", printf_header);
        dwc_ddrphy_phyinit_cmnt ("%s // ####################################################\n", printf_header);
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].Reserved00 = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].Reserved00); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].MsgMisc = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].MsgMisc); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].Pstate = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].Pstate); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].PllBypassEn = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].PllBypassEn); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].DRAMFreq = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].DRAMFreq); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].DfiFreqRatio = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].DfiFreqRatio); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].BPZNResVal = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].BPZNResVal); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].PhyOdtImpedance = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].PhyOdtImpedance); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].PhyDrvImpedance = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].PhyDrvImpedance); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].PhyVref = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].PhyVref); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].DramType = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].DramType); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].DisabledDbyte = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].DisabledDbyte); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].EnabledDQs = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].EnabledDQs); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].CsPresent = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].CsPresent); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].CsPresentD0 = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].CsPresentD0); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].CsPresentD1 = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].CsPresentD1); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].AddrMirror = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].AddrMirror); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].PhyCfg = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].PhyCfg); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].SequenceCtrl = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].SequenceCtrl); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].HdtCtrl = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].HdtCtrl); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].Share2DVrefResult = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].Share2DVrefResult); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].Reserved1E = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].Reserved1E); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].PhyConfigOverride = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].PhyConfigOverride); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].DFIMRLMargin = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].DFIMRLMargin); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].MR0 = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].MR0); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].MR1 = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].MR1); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].MR2 = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].MR2); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].AcsmOdtCtrl0 = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].AcsmOdtCtrl0); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].AcsmOdtCtrl1 = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].AcsmOdtCtrl1); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].AcsmOdtCtrl2 = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].AcsmOdtCtrl2); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].AcsmOdtCtrl3 = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].AcsmOdtCtrl3); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].AcsmOdtCtrl4 = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].AcsmOdtCtrl4); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].AcsmOdtCtrl5 = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].AcsmOdtCtrl5); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].AcsmOdtCtrl6 = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].AcsmOdtCtrl6); 
        dwc_ddrphy_phyinit_cmnt ("%s mb_DDR3U_1D[%d].AcsmOdtCtrl7 = 0x%x\n", printf_header, ps, mb_DDR3U_1D[ps].AcsmOdtCtrl7); 

    }

}
/** @} */
