Copyright 2019 Synopsys, Inc.
This Synopsys IP and all associated documentation are proprietary to
Synopsys, Inc. and may only be used pursuant to the terms and conditions
of a written license agreement with Synopsys, Inc. All other use,
reproduction, modification, or distribution of the Synopsys IP or the
associated documentation is strictly prohibited.
------------------------------------------------------------------


LPDDR4_MULTIPHY_V2 Customer Testbench

The Customer Testbench is a simulation demonstration
environment intended to provide a Verilog example testbench.

Version A-2018.10-SP1-DDR3L
30-Apr-2019

Changes from version A-2018.10-SP1

This version only contains support for DDR3/DDR3L. All other protocols have been removed.
This is version is to be used with the dwc_ap_lpddr4x_multiphy_tsmc16ffc18 to augment
LPDDR4X, LPDDR4, and DDR4


------------------------------------------------------------------

Version A-2018.10-SP1
Nov 27, 2018

Changes from version A-2018.10
(recommended)

Special Notes
-------------
- This testbench has been validated with tool versions and PHY component versions
  listed below. The testbench may not operate properly if used with versions other
  than identified.

Enhancements
-------------
- Update MEMVIP version to N-2018.03 
- Enhancements to gate level support

Unsupported Features
---------------------
The following features are NOT supported:
  - LPDDR2 protocol is not supported
  - ACX8 configuration is not supported

Firmware and/or RTL includes code of unsupported features that do not affect the operation of supported features. 
The PHY has been simulation regressed to ensure the supported features are not impacted by the inclusion of these unsupported features. 
The unsupported features must not be used and Synopsys will not address queries related to these unsupported features.

EDA Support
-------------
This section lists the EDA tools and versions used during the QA testing of
this release.
    Synopsys VCS (Verilog Simulation)
        - 2017.12-SP1
    Synopsys Verdi (Verilog HW Debug)
        - 2017.03-SP1
    Synopsys DesignWare (VIP Models)
        - # Using svt version ddr_svt_M-2017.06
        - # Using svt version lpddr_svt_M-2017.06


Minimum Required Versions
-------------------------
- Phyinit:  A-2018.10
- Firmware: A-2018.10
- PUB:      2.11a
- Hard Macros Family: Type A/B/D/E


Please refer to the Implementation Guide (chapter 3 Customer Testbench) in the
<release>/doc directory.

------------------------------------------------------------------

Version A-2018.10
Oct 1, 2018

Updated version (under continued Beta Testing)

Special Notes
-------------
- This testbench has been validated with tool versions and PHY component versions
  listed below. The testbench may not operate properly if used with versions other
  than identified.

Enhancements
-------------
- Support MASIS pattern generation
- Support HWEMUL mode for DDR4 UDIMM and LPDDR4 demo_basic test

Unsupported Features
---------------------
The following features are NOT supported:
  - LPDDR2 protocol is not supported
  - ACX8 configuration is not supported

Firmware and/or RTL includes code of unsupported features that do not affect the operation of supported features. 
The PHY has been simulation regressed to ensure the supported features are not impacted by the inclusion of these unsupported features. 
The unsupported features must not be used and Synopsys will not address queries related to these unsupported features.


EDA Support
-------------
This section lists the EDA tools and versions used during the QA testing of
this release.
    Synopsys VCS (Verilog Simulation)
        - 2017.12-SP1
    Synopsys Verdi (Verilog HW Debug)
        - 2017.03-SP1
    Synopsys DesignWare (VIP Models)
        - # Using svt version ddr_svt_M-2017.06


Minimum Required Versions
-------------------------
- Phyinit:  A-2018.10
- Firmware: A-2018.10
- PUB:      2.11a
- Hard Macros Family: Type A/B/D/E


Please refer to the Implementation Guide (chapter 3 Customer Testbench) in the
<release>/doc directory.

------------------------------------------------------------------

Version A-2018.05
May 1, 2018

Updated version (under continued Beta Testing)

Special Notes
--------------
- This testbench has been validated with tool versions and PHY component versions
  listed below. The testbench may not operate properly if used with versions other
  than identified.

Enhancements
-------------
- Support ATE test for all RTL configuration

EDA Support
-------------
This section lists the EDA tools and versions used during the QA testing of
this release.
    Synopsys VCS (Verilog Simulation)
        - 2017.03-SP1
    Synopsys Verdi (Verilog HW Debug)
        - 2017.03-SP1
    Synopsys DesignWare (VIP Models)
        - # Using svt version ddr_svt_M-2017.06
        - # Using svt version lpddr_svt_M-2017.06


Minimum Required Versions
---------------------------
- Phyinit:  A-2018.05
- Firmware: A-2018.05
- PUB:      2.30a
- Hard Macros Family: Type A/B/D/E


Please refer to the Customer Testbench Application Note in the
<release>/doc directory.

------------------------------------------------------------------

Version A-2017.11
November 1, 2017

Updated version (under continued Beta Testing)

Special Notes
--------------
- This testbench has been validated with tool versions and PHY component versions
  listed below. The testbench may not operate properly if used with versions other
  than identified.

Enhancements
-------------
- Unify the test cases
- Support DFI Freq change
- Support LPDDR3 protocol
- Support TDR interface
- Support PLL bypass mode
- Support low power(dfi_lp/LP2/LP3/IO retention)

EDA Support
-------------
This section lists the EDA tools and versions used during the QA testing of
this release.
    Synopsys VCS (Verilog Simulation)
        - 2017.03
    Synopsys Verdi (Verilog HW Debug)
        - 2017.03
    Synopsys DesignWare (VIP Models)
        - # Using svt version ddr_svt_M-2017.06
        - # Using svt version lpddr_svt_M-2017.06


Minimum Required Versions
---------------------------
- Phyinit:  A-2017.11
- Firmware: A-2017.11
- PUB:      2.11a
- Hard Macros Family: Type A/B/D/E


Please refer to the Customer Testbench Application Note in the
<release>/doc directory.

------------------------------------------------------------------

Version A-2017.09
September 1, 2017

Updated version (under continued Beta Testing)

Special Notes
--------------
- This testbench has been validated with tool versions and PHY component versions
  listed below. The testbench may not operate properly if used with versions other
  than identified.

Enhancements
-------------
- Update MemVIP catalog files
- Clean unexpected MemVIP Errors

EDA Support
-------------
This section lists the EDA tools and versions used during the QA testing of
this release.
    Synopsys VCS (Verilog Simulation)
        - 2017.03
    Synopsys Verdi (Verilog HW Debug)
        - 2017.03
    Synopsys DesignWare (VIP Models)
        - # Using svt version ddr_svt_M-2017.06
        - # Using svt version lpddr_svt_M-2017.06


Minimum Required Versions
---------------------------
- Phyinit:  A-2017.09
- Firmware: A-2017.09
- PUB:      2.10a
- Hard Macros Family: Type A/B/D/E


Please refer to the Customer Testbench Application Note in the
<release>/doc directory.

------------------------------------------------------------------

Version A-2017.07
July 7, 2017

Updated version (under continued Beta Testing)

Special Notes
--------------
- This testbench has been validated with tool versions and PHY component versions
  listed below. The testbench may not operate properly if used with versions other
  than identified.

Enhancements
-------------
- Add support to different AC/DByte combination. [Note]: DByte number 1/2/9
  are not supported yet
- Add support to different frequency/speed-bin
- Add support to different freq_ratio(1:1, 1:2, 1:4)
- Add demo_lpddr4_devinit case
- Add new runtc command which merges previous two runtc steps
- Add debug option to select different message verbosity
- Implement phyInit customer tasks in CTB
- Generate rtl_rel.f automatically

EDA Support
-------------
This section lists the EDA tools and versions used during the QA testing of
this release.
    Synopsys VCS (Verilog Simulation)
        - 2017.03
    Synopsys Verdi (Verilog HW Debug)
        - 2017.03
    Synopsys DesignWare (VIP Models)
        - # Using svt version ddr_svt_M-2017.06
        - # Using svt version lpddr_svt_M-2017.06


Minimum Required Versions
---------------------------
- Phyinit:  A-2017.07
- Firmware: A-2017.07
- PUB:      2.10a
- Hard Macros Family: Type A/B/D/E


Please refer to the Customer Testbench Application Note in the
<release>/doc directory.

------------------------------------------------------------------
