------------------------------------------------------------------
Copyright 2019 Synopsys, Inc.
This Synopsys IP and all associated documentation are proprietary to
Synopsys, Inc. and may only be used pursuant to the terms and conditions
of a written license agreement with Synopsys, Inc. All other use,
reproduction, modification, or distribution of the Synopsys IP or the
associated documentation is strictly prohibited.
------------------------------------------------------------------
DDR3L Supplimental Release

29-April-2019

This release support Firmware, Phyinit, and CTB for DDR3/DDR3L.
It is derived from lpddr4_multiphy_v2 and adapted to lpddr4x_multiphy.

It uses the following releases
- Firmware A-2018.10-DDR3L
- Phyinit  A-2018.10-SP2-DDR3L
- CTB      A-2018.10-SP1-DDR3L