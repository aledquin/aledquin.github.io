#! /usr/bin/env perl

if ( $ARGV[0] == 0 ){ # release =0
  system ("chmod 777 $ARGV[1]");
  system ("chmod 777 $ARGV[2]");
  open (Af, "<$ARGV[1]") or die "ERROR:can not open $ARGV[1] for read!!!";
  open (Bf, ">$ARGV[2]") or die "ERROR:can not open $ARGV[2] for write!!!";
  print Bf "\$\{BUILD_PATH\}\n";
  print Bf "//Top\ndwc_ddrphy_top.v\n";
  while (<Af>){
    if ($_ =~ /dwc_ddrphy_top\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphyacx4_top\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_cmdfifo4\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_atxbit\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_prbs7chkx1\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dftclkmux\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_lcdl_tx\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_lcdl\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_cmdfifo2\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_cmdfifo5\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphydbyte_top\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dlane_txfifo\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dqs_txfifo\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_data_fifo_rx\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_phfifo\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_phfifo7b\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_phfifo1b\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_lcdl_rxen\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_lcdl_rxclk\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dll_rsm\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dll_rxen_training\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dlldrv\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphymaster_top\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_cmpmeas\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_pllwrap\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_pll\.v/) { print Bf "\/\/";}
    print Bf $_;
  }

  if($ARGV[6] eq 'ns') {
    print Bf " 
  //GateSim Custom circuit update
  \$CTB_HOME/../../process/\$gatesim_project/sim/ddrphy_lcdl_ns.v\n";
  } elsif ($ARGV[6] eq 'ew') {
    print Bf " 
  //GateSim Custom circuit update
  \$CTB_HOME/../../process/\$gatesim_project/sim/ddrphy_lcdl_ew.v\n";
  } else {
    print Bf " 
  //GateSim Custom circuit update
  \$CTB_HOME/../../process/\$gatesim_project/sim/ddrphy_lcdl.v\n";
  }
  #custom circuit
  print Bf " 
//GateSim Custom circuit update
\$CTB_HOME/../../process/\$gatesim_project/sim/dwc_ddrphy_drvlsaw_ew.v
\$CTB_HOME/../../process/\$gatesim_project/sim/dwc_ddrphy_drvlsaw_ns.v
\$CTB_HOME/../../process/\$gatesim_project/sim/dwc_ddrphy_txrxca_ew.v
\$CTB_HOME/../../process/\$gatesim_project/sim/dwc_ddrphy_txrxca_ns.v
\$CTB_HOME/../../process/\$gatesim_project/sim/dwc_ddrphy_txrxdq_ew.v
\$CTB_HOME/../../process/\$gatesim_project/sim/dwc_ddrphy_txrxdq_ns.v
\$CTB_HOME/../../process/\$gatesim_project/sim/dwc_ddrphy_txrxdqs_ew.v
\$CTB_HOME/../../process/\$gatesim_project/sim/dwc_ddrphy_txrxdqs_ns.v
\$CTB_HOME/../../process/\$gatesim_project/sim/dwc_ddrphy_drvlsdw_ew.v
\$CTB_HOME/../../process/\$gatesim_project/sim/dwc_ddrphy_drvlsdw_ns.v
\$CTB_HOME/../../process/\$gatesim_project/sim/dwc_ddrphy_pll_ns.v\n";
  
print Bf "\$CTB_HOME/gatesim_script/dummy.v\n"; 
if($ARGV[5] eq 'undefined') {
  print Bf "
//GateSim hard macro netlist with PG
\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphymaster_top/views/behavior/dwc_ddrphymaster_top_pg.v \n";
  if($ARGV[3] eq 'ns') {
      print Bf "\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphyacx4_top_ns/views/behavior/dwc_ddrphyacx4_top_ns_pg.v\n";
  }
  if($ARGV[3] eq 'ew') {
      print Bf "\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphyacx4_top_ew/views/behavior/dwc_ddrphyacx4_top_ew_pg.v\n";
  }
  if($ARGV[3] eq 'mix') {
      print Bf "\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphyacx4_top_ew/views/behavior/dwc_ddrphyacx4_top_ew_pg.v\n";
      print Bf "\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphyacx4_top_ns/views/behavior/dwc_ddrphyacx4_top_ns_pg.v\n";
  }
  
  if($ARGV[4] eq 'ns') {
      print Bf "\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphydbyte_top_ns/views/behavior/dwc_ddrphydbyte_top_ns_pg.v\n";
  }
  if($ARGV[4] eq 'ew') {
      print Bf "\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphydbyte_top_ew/views/behavior/dwc_ddrphydbyte_top_ew_pg.v\n";
  }
  if($ARGV[4] eq 'mix') {
      print Bf "\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphydbyte_top_ns/views/behavior/dwc_ddrphydbyte_top_ns_pg.v\n";
      print Bf "\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphydbyte_top_ew/views/behavior/dwc_ddrphydbyte_top_ew_pg.v\n";
  } 
  } else {
  print Bf "
//GateSim hard macro netlist with PG
\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphymaster_top/views/behavior/\$sdf_path/dwc_ddrphymaster_top_pg.v \n";
  if($ARGV[3] eq 'ns') {
      print Bf "\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphyacx4_top_ns/views/behavior/\$sdf_path/dwc_ddrphyacx4_top_ns_pg.v\n";
  }
  if($ARGV[3] eq 'ew') {
      print Bf "\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphyacx4_top_ew/views/behavior/\$sdf_path/dwc_ddrphyacx4_top_ew_pg.v\n";
  }
  if($ARGV[3] eq 'mix') {
      print Bf "\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphyacx4_top_ew/views/behavior/\$sdf_path/dwc_ddrphyacx4_top_ew_pg.v\n";
      print Bf "\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphyacx4_top_ns/views/behavior/\$sdf_path/dwc_ddrphyacx4_top_ns_pg.v\n";
  }
  
  if($ARGV[4] eq 'ns') {
      print Bf "\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphydbyte_top_ns/views/behavior/\$sdf_path/dwc_ddrphydbyte_top_ns_pg.v\n";
  }
  if($ARGV[4] eq 'ew') {
      print Bf "\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphydbyte_top_ew/views/behavior/\$sdf_path/dwc_ddrphydbyte_top_ew_pg.v\n";
  }
  if($ARGV[4] eq 'mix') {
      print Bf "\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphydbyte_top_ns/views/behavior/\$sdf_path/dwc_ddrphydbyte_top_ns_pg.v\n";
      print Bf "\$CTB_HOME/../../process/\$gatesim_project/dwc_ddrphydbyte_top_ew/views/behavior/\$sdf_path/dwc_ddrphydbyte_top_ew_pg.v\n";
  } 
  }  
}


if ( $ARGV[0] == 1 ){ # release =1
  system ("chmod 777 $ARGV[1]");
  system ("chmod 777 $ARGV[2]");
  open (Af, "<$ARGV[1]") or die "ERROR:can not open $ARGV[1] for read!!!";
  open (Bf, ">$ARGV[2]") or die "ERROR:can not open $ARGV[2] for write!!!";
  if ( $ARGV[5] == 1 ) {
  print Bf "\$\{TB_BUILD_PATH\}\n";
  } else {
  print Bf "\$\{BUILD_PATH\}\n";
  }
  while (<Af>){
    if ($_ =~ /dwc_ddrphyacx4_top\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_cmdfifo4\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_atxbit\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_prbs7chkx1\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dftclkmux\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_lcdl_tx\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_cmdfifo2\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_cmdfifo5\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphydbyte_top\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dlane_txfifo\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dqs_txfifo\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_data_fifo_rx\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_phfifo\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_phfifo7b\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_phfifo1b\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_lcdl_rxen\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_lcdl_rxclk\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dll_rsm\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dll_rxen_training\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dlldrv\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphymaster_top\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_cmpmeas\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_pllwrap\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_pll\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_lcdl\.v/) { print Bf "\/\/";}
    print Bf $_;
  }
  if($ARGV[3] eq 'ns') {
      if($ARGV[7] eq 'ns') {
        print Bf "//GateSim Custom circuit update
                \$CTB_HOME/../../acx4_ns/Latest/include/ddrphy_lcdl_ns.v\n";
      } elsif ($ARGV[7] eq 'ew') {
        print Bf "//GateSim Custom circuit update
                \$CTB_HOME/../../acx4_ns/Latest/include/ddrphy_lcdl_ew.v\n";
      } else {
        print Bf "//GateSim Custom circuit update
                \$CTB_HOME/../../acx4_ns/Latest/include/ddrphy_lcdl.v\n";
      }
      print Bf "//GateSim Custom circuit update
                \$CTB_HOME/../../acx4_ns/Latest/include/dwc_ddrphy_drvlsaw_ew.v
                \$CTB_HOME/../../acx4_ns/Latest/include/dwc_ddrphy_drvlsaw_ns.v
                \$CTB_HOME/../../acx4_ns/Latest/include/dwc_ddrphy_txrxca_ew.v
                \$CTB_HOME/../../acx4_ns/Latest/include/dwc_ddrphy_txrxca_ns.v\n";
  }
  if($ARGV[3] eq 'ew') {
      if($ARGV[7] eq 'ns') {
        print Bf "//GateSim Custom circuit update
                \$CTB_HOME/../../acx4_ew/Latest/include/ddrphy_lcdl_ns.v\n";
      } elsif ($ARGV[7] eq 'ew') {
        print Bf "//GateSim Custom circuit update
                \$CTB_HOME/../../acx4_ew/Latest/include/ddrphy_lcdl_ew.v\n";
      } else {
        print Bf "//GateSim Custom circuit update
                \$CTB_HOME/../../acx4_ew/Latest/include/ddrphy_lcdl.v\n";
      }
      print Bf "//GateSim Custom circuit update
                \$CTB_HOME/../../acx4_ew/Latest/include/dwc_ddrphy_drvlsaw_ew.v
                \$CTB_HOME/../../acx4_ew/Latest/include/dwc_ddrphy_drvlsaw_ns.v
                \$CTB_HOME/../../acx4_ew/Latest/include/dwc_ddrphy_txrxca_ew.v
                \$CTB_HOME/../../acx4_ew/Latest/include/dwc_ddrphy_txrxca_ns.v\n";
  }
  if($ARGV[3] eq 'mix') {
      if($ARGV[7] eq 'ns') {
        print Bf "//GateSim Custom circuit update
                \$CTB_HOME/../../acx4_ew/Latest/include/ddrphy_lcdl_ns.v\n";
      } elsif ($ARGV[7] eq 'ew') {
        print Bf "//GateSim Custom circuit update
                \$CTB_HOME/../../acx4_ew/Latest/include/ddrphy_lcdl_ew.v\n";
      } else {
        print Bf "//GateSim Custom circuit update
                \$CTB_HOME/../../acx4_ew/Latest/include/ddrphy_lcdl.v\n";
      }
      print Bf "//GateSim Custom circuit update
                \$CTB_HOME/../../acx4_ew/Latest/include/dwc_ddrphy_drvlsaw_ew.v
                \$CTB_HOME/../../acx4_ew/Latest/include/dwc_ddrphy_drvlsaw_ns.v
                \$CTB_HOME/../../acx4_ew/Latest/include/dwc_ddrphy_txrxca_ew.v
                \$CTB_HOME/../../acx4_ew/Latest/include/dwc_ddrphy_txrxca_ns.v\n";
  }
  
  if($ARGV[4] eq 'ns') {
      print Bf "//GateSim Custom circuit update
                \$CTB_HOME/../../dbyte_ns/Latest/include/dwc_ddrphy_txrxdq_ew.v
                \$CTB_HOME/../../dbyte_ns/Latest/include/dwc_ddrphy_txrxdq_ns.v
                \$CTB_HOME/../../dbyte_ns/Latest/include/dwc_ddrphy_txrxdqs_ew.v
                \$CTB_HOME/../../dbyte_ns/Latest/include/dwc_ddrphy_txrxdqs_ns.v
                \$CTB_HOME/../../dbyte_ns/Latest/include/dwc_ddrphy_drvlsdw_ew.v
                \$CTB_HOME/../../dbyte_ns/Latest/include/dwc_ddrphy_drvlsdw_ns.v\n";
  } 
  if($ARGV[4] eq 'ew') {
      print Bf "//GateSim Custom circuit update
                \$CTB_HOME/../../dbyte_ew/Latest/include/dwc_ddrphy_txrxdq_ew.v
                \$CTB_HOME/../../dbyte_ew/Latest/include/dwc_ddrphy_txrxdq_ns.v
                \$CTB_HOME/../../dbyte_ew/Latest/include/dwc_ddrphy_txrxdqs_ew.v
                \$CTB_HOME/../../dbyte_ew/Latest/include/dwc_ddrphy_txrxdqs_ns.v
                \$CTB_HOME/../../dbyte_ew/Latest/include/dwc_ddrphy_drvlsdw_ew.v
                \$CTB_HOME/../../dbyte_ew/Latest/include/dwc_ddrphy_drvlsdw_ns.v\n";
  }
  if($ARGV[4] eq 'mix') {
      print Bf "//GateSim Custom circuit update
                \$CTB_HOME/../../dbyte_ew/Latest/include/dwc_ddrphy_txrxdq_ew.v
                \$CTB_HOME/../../dbyte_ew/Latest/include/dwc_ddrphy_txrxdq_ns.v
                \$CTB_HOME/../../dbyte_ew/Latest/include/dwc_ddrphy_txrxdqs_ew.v
                \$CTB_HOME/../../dbyte_ew/Latest/include/dwc_ddrphy_txrxdqs_ns.v
                \$CTB_HOME/../../dbyte_ew/Latest/include/dwc_ddrphy_drvlsdw_ew.v
                \$CTB_HOME/../../dbyte_ew/Latest/include/dwc_ddrphy_drvlsdw_ns.v\n";
  }
  print Bf "//GateSim Custom circuit update
\$CTB_HOME/../../master/Latest/include/dwc_ddrphy_pll_ns.v\n";
  if ( $ARGV[5] == 1 ) {
    if ( $ARGV[6] == 1 ) {
       print Bf "\$CTB_HOME/gatesim_script/dummy.v\n"; 
       print Bf "//Top\n\$CTB_HOME/../../hardening_dir/dwc_ddrphy_top.v\n";
    } else {
       print Bf "\$CTB_HOME/gatesim_script/dummy.v\n"; 
       print Bf "//Top\n\$CTB_HOME/../../hardening_dir/dwc_ddrphy_top_pg.v\n";
    }
  } else {
  print Bf "//Top\ndwc_ddrphy_top.v\n";
  print Bf "\$CTB_HOME/gatesim_script/dummy.v\n"; 
  }
  print Bf "
  //GateSim hard macro netlist with PG
  \$CTB_HOME/../../master/Latest/behavior/\$sdf_path/dwc_ddrphymaster_top_pg.v \n";
  if($ARGV[3] eq 'ns') {
   print Bf "\$CTB_HOME/../../acx4_ns/Latest/behavior/\$sdf_path/dwc_ddrphyacx4_top_ns_pg.v\n";
  }
  if($ARGV[3] eq 'ew') {
      print Bf "\$CTB_HOME/../../acx4_ew/Latest/behavior/\$sdf_path/dwc_ddrphyacx4_top_ew_pg.v\n";
  }
  if($ARGV[3] eq 'mix') {
      print Bf "\$CTB_HOME/../../acx4_ew/Latest/behavior/\$sdf_path/dwc_ddrphyacx4_top_ew_pg.v\n";
      print Bf "\$CTB_HOME/../../acx4_ns/Latest/behavior/\$sdf_path/dwc_ddrphyacx4_top_ns_pg.v\n";
  }
  if($ARGV[4] eq 'ns') {
      print Bf "\$CTB_HOME/../../dbyte_ns/Latest/behavior/\$sdf_path/dwc_ddrphydbyte_top_ns_pg.v\n";
  }
  if($ARGV[4] eq 'ew') {
      print Bf "\$CTB_HOME/../../dbyte_ew/Latest/behavior/\$sdf_path/dwc_ddrphydbyte_top_ew_pg.v\n";
  }
  if($ARGV[4] eq 'mix') {
      print Bf "\$CTB_HOME/../../dbyte_ew/Latest/behavior/\$sdf_path/dwc_ddrphydbyte_top_ew_pg.v\n";
      print Bf "\$CTB_HOME/../../dbyte_ns/Latest/behavior/\$sdf_path/dwc_ddrphydbyte_top_ns_pg.v\n";
  }
}   

if ( $ARGV[0] == 2 ){ # release =2
  system ("chmod 777 $ARGV[1]");
  system ("chmod 777 $ARGV[2]");
  open (Af, "<$ARGV[1]") or die "ERROR:can not open $ARGV[1] for read!!!";
  open (Bf, ">$ARGV[2]") or die "ERROR:can not open $ARGV[2] for write!!!";
  print Bf "\$\{BUILD_PATH\}\n";
  print Bf "//Top\ndwc_ddrphy_top.v\n";
  while (<Af>){
    if ($_ =~ /dwc_ddrphyacx4_top\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_cmdfifo4\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_atxbit\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_prbs7chkx1\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dftclkmux\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_lcdl_tx\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_lcdl\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_cmdfifo2\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_cmdfifo5\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphydbyte_top\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dlane_txfifo\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dqs_txfifo\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_data_fifo_rx\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_phfifo\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_phfifo7b\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_phfifo1b\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_lcdl_rxen\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_lcdl_rxclk\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dll_rsm\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dll_rxen_training\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_dlldrv\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphymaster_top\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_cmpmeas\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_pllwrap\.v/) { print Bf "\/\/";}
    if ($_ =~ /dwc_ddrphy_pll\.v/) { print Bf "\/\/";}
    print Bf $_;
  }
  #custom circuit
  if($ARGV[6] eq 'ns') {
    print Bf " 
  //GateSim Custom circuit update
  \$CTB_HOME/../../../../../../../process/\$gatesim_project/sim/ddrphy_lcdl_ns.v\n";
  } elsif ($ARGV[6] eq 'ew') {
    print Bf " 
  //GateSim Custom circuit update
  \$CTB_HOME/../../../../../../../process/\$gatesim_project/sim/ddrphy_lcdl_ew.v\n";
  } else {
    print Bf " 
  //GateSim Custom circuit update
  \$CTB_HOME/../../../../../../../process/\$gatesim_project/sim/ddrphy_lcdl.v\n";
  }
  print Bf " 
//GateSim Custom circuit update
\$CTB_HOME/../../../../../../../process/\$gatesim_project/sim/dwc_ddrphy_drvlsaw_ew.v
\$CTB_HOME/../../../../../../../process/\$gatesim_project/sim/dwc_ddrphy_drvlsaw_ns.v
\$CTB_HOME/../../../../../../../process/\$gatesim_project/sim/dwc_ddrphy_txrxca_ew.v
\$CTB_HOME/../../../../../../../process/\$gatesim_project/sim/dwc_ddrphy_txrxca_ns.v
\$CTB_HOME/../../../../../../../process/\$gatesim_project/sim/dwc_ddrphy_txrxdq_ew.v
\$CTB_HOME/../../../../../../../process/\$gatesim_project/sim/dwc_ddrphy_txrxdq_ns.v
\$CTB_HOME/../../../../../../../process/\$gatesim_project/sim/dwc_ddrphy_txrxdqs_ew.v
\$CTB_HOME/../../../../../../../process/\$gatesim_project/sim/dwc_ddrphy_txrxdqs_ns.v
\$CTB_HOME/../../../../../../../process/\$gatesim_project/sim/dwc_ddrphy_drvlsdw_ew.v
\$CTB_HOME/../../../../../../../process/\$gatesim_project/sim/dwc_ddrphy_drvlsdw_ns.v
\$CTB_HOME/../../../../../../../process/\$gatesim_project/sim/dwc_ddrphy_pll_ns.v\n";
  print Bf "\$CTB_HOME/gatesim_script/dummy.v\n"; 
  if($ARGV[5] eq 'undefined') {
  print Bf "
  //GateSim hard macro netlist with PG
  \$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphymaster_top/views/behavior/dwc_ddrphymaster_top_pg.v\n"; 
  if($ARGV[3] eq 'ns') {
      print Bf "
\$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphyacx4_top_ns/views/behavior/dwc_ddrphyacx4_top_ns_pg.v\n";
  }
  if($ARGV[3] eq 'ew') {
      print Bf "
\$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphyacx4_top_ew/views/behavior/dwc_ddrphyacx4_top_ew_pg.v\n";
  }
  if($ARGV[3] eq 'mix') {
      print Bf "
\$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphyacx4_top_ew/views/behavior/dwc_ddrphyacx4_top_ew_pg.v\n";
      print Bf "
\$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphyacx4_top_ns/views/behavior/dwc_ddrphyacx4_top_ns_pg.v\n";
  }
  
  if($ARGV[4] eq 'ns') {
      print Bf "
\$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphydbyte_top_ns/views/behavior/dwc_ddrphydbyte_top_ns_pg.v\n";
  }
  if($ARGV[4] eq 'ew') {
      print Bf "
\$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphydbyte_top_ew/views/behavior/dwc_ddrphydbyte_top_ew_pg.v\n";
  }
  if($ARGV[4] eq 'mix') {
      print Bf "
\$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphydbyte_top_ns/views/behavior/dwc_ddrphydbyte_top_ns_pg.v\n";
      print Bf "
\$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphydbyte_top_ew/views/behavior/dwc_ddrphydbyte_top_ew_pg.v\n";
  } 
  } else {
  print Bf "
  //GateSim hard macro netlist with PG
  \$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphymaster_top/views/behavior/\$sdf_path/dwc_ddrphymaster_top_pg.v\n"; 
  if($ARGV[3] eq 'ns') {
      print Bf "
\$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphyacx4_top_ns/views/behavior/\$sdf_path/dwc_ddrphyacx4_top_ns_pg.v\n";
  }
  if($ARGV[3] eq 'ew') {
      print Bf "
\$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphyacx4_top_ew/views/behavior/\$sdf_path/dwc_ddrphyacx4_top_ew_pg.v\n";
  }
  if($ARGV[3] eq 'mix') {
      print Bf "
\$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphyacx4_top_ew/views/behavior/\$sdf_path/dwc_ddrphyacx4_top_ew_pg.v\n";
      print Bf "
\$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphyacx4_top_ns/views/behavior/\$sdf_path/dwc_ddrphyacx4_top_ns_pg.v\n";
  }
  
  if($ARGV[4] eq 'ns') {
      print Bf "
\$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphydbyte_top_ns/views/behavior/\$sdf_path/dwc_ddrphydbyte_top_ns_pg.v\n";
  }
  if($ARGV[4] eq 'ew') {
      print Bf "
\$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphydbyte_top_ew/views/behavior/\$sdf_path/dwc_ddrphydbyte_top_ew_pg.v\n";
  }
  if($ARGV[4] eq 'mix') {
      print Bf "
\$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphydbyte_top_ns/views/behavior/\$sdf_path/dwc_ddrphydbyte_top_ns_pg.v\n";
      print Bf "
\$CTB_HOME/../../../../../../../process/\$gatesim_project/dwc_ddrphydbyte_top_ew/views/behavior/\$sdf_path/dwc_ddrphydbyte_top_ew_pg.v\n";
  }   
  }
}

