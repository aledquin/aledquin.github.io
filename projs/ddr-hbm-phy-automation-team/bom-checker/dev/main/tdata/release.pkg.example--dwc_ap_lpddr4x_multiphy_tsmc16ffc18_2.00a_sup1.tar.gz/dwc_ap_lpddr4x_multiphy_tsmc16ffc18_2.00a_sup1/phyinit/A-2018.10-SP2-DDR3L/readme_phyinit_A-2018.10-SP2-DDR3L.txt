Copyright 2019 Synopsys, Inc.
This Synopsys IP and all associated documentation are proprietary to
Synopsys, Inc. and may only be used pursuant to the terms and conditions
of a written license agreement with Synopsys, Inc. All other use,
reproduction, modification, or distribution of the Synopsys IP or the
associated documentation is strictly prohibited.
------------------------------------------------------------------
LPDDR4_MULTIPHY_V2 PHYINIT

The PHYINIT software is a utility intended to provide usability assistance and
guidance to customers for PHY initialization, in the form of overall procedure
and CSR writes/configurations. The PHYINIT is intended to be a supplement to
be used in conjunction with all PHY related documentation (PUB/PHY Databooks,
Application Notes, Stars on the Web, and others). The user must follow the
procedures and CSR writes/configurations as outlined in the documentation, and
must not solely rely on the PHYINIT utility to guarantee correct operation for
their configuration, platform, SoC and other implementation specific
considerations.

------------------------------------------------------------------
Version A-2018.10-SP2-DDR3L
30-Apr-2019

Changes from version A-2018.10-SP2

This version only contains support for DDR3/DDR3L. All other protocols have been removed.
This is version is to be used with the dwc_ap_lpddr4x_multiphy_tsmc16ffc18 to augment
LPDDR4X, LPDDR4, and DDR4

------------------------------------------------------------------
Version A-2018.10-SP2
February 13, 2019

Changes from version A-2018.10-SP1
(optional)

Bug Fixes
---------
- Fixed STAR 9001407866: Incorrect PIE sequence may cause BP_MEMRESET_L glitch


Minimum Required Versions
-------------------------
- Firmware: A-2017.05
- PUB: 1.00a

------------------------------------------------------------------
Version A-2018.10-SP1 
January 24, 2019

Changes from version A-2018.10
(optional)

Special Notes
-----------

Enhancements
-----------
- There are NO functional changes in this release.
- Corrected an error in the /software/README file.
  The change is:
    FROM -> Edit the content of ./<protocol>/dwc_ddrphy_PhyInit_setDefault.c 
    TO->    Edit the content of ./<protocol>/userCustom/dwc_ddrphy_phyinit_setDefault.c 

Unsupported Features
---------------------
The following features are NOT supported:
  - ACX8 configuration is not supported

Firmware and/or RTL includes code of unsupported features that do not affect the operation of supported features. 
The PHY has been simulation regressed to ensure the supported features are not impacted by the inclusion of these unsupported features. 
The unsupported features must not be used and Synopsys will not address queries related to these unsupported features. 

Compiler Version Used
---------------------
Compiler version used during the QA testing of this release.
- gcc 4.7.2

Minimum Required Versions
-------------------------
- Firmware: A-2017.05
- PUB: 1.00a

------------------------------------------------------------------
Version A-2018.10 
October 18, 2018

Changes from version A-2018.05
(recommended)

Special Notes
-----------

Enhancements
-----------
- default DimmType set to NODIMM for LPDDR3/4/4X
- LPDDR4: message block variable RTT_NOM_WR_PARK0-7 were not initialized
  correctly in dwc_ddrphy_phyinit_setDefault.
- Default value for following registers updated based on silicon feedback:
  - DllGainCtl = 0x61
  - DllLockParam = 0x212
- LPDDR4: enhancement to prevent the PHY sending command to unpopulated ranks
  during read gate re-training.
- Removed strcmp() calls from dwc_ddrphy_phyinit_mapDrvStren().
- LPDDR3, DDR3: Bug fix to set CalDrvStrPu50 and CalDrvStrPd50 based on 
  userInputAdvanced.ExtCalResVal.

Unsupported Features
---------------------
The following features are NOT supported:
  - LPDDR2 protocol is not supported
  - ACX8 configuration is not supported

Firmware and/or RTL includes code of unsupported features that do not affect the operation of supported features. 
The PHY has been simulation regressed to ensure the supported features are not impacted by the inclusion of these unsupported features. 
The unsupported features must not be used and Synopsys will not address queries related to these unsupported features.

Compiler Version Used
---------------------
Compiler version used during the QA testing of this release.
- gcc 4.7.2

Minimum Required Versions
-------------------------
- Firmware: A-2017.05
- PUB: 1.00a
 
------------------------------------------------------------------
Version A-2018.05 
May 4, 2018

Changes from version A-2017.11
(recommended)

Special Notes
-----------
  
Enhancements
-----------
- LPDDR4: fixed a bug in programming DocByteSel in Mixed mode devices.
- fixed a bug where following registers where not saved during
  retention/restore:
   - DWC_DDRPHYA_DBYTE0_RxPBDlyTg0_r2-r8
   - DWC_DDRPHYA_DBYTE0_VrefDAC*_r2-r8
- Improved GlobalVrefInDAC programming to intelligently select between
  supported Vref range instead of manual programming.
- Added programing of CalVRefs and CalDrvStr* for HME macro family.
- Added the following features. Please see PhyInit HTML documentation for
  details: 
    - EnableHighClkSkewFix
    - DisableUnusedAddrLns
    - PhyInitSequenceNum
    - Lp4LowPowerDrv 

Compiler Version Used
---------------------
Compiler version used during the QA testing of this release.
- gcc 4.7.2

Minimum Required Versions
-------------------------
- Firmware: A-2017.05
- PUB: 1.00a
 
------------------------------------------------------------------
Version A-2017.11 
November 3, 2017

Changes from version A-2017.09
(recommended)

Special Notes
-----------
  
Enhancements
-----------
- Updated PhyInit logic to disable DBI receivers when Read DBI is not used in
  order to save power.
- Disabled MessageBlock auto calculation for unused Pstates.
- Added assertion to highlight PHY cannot set MR4 in DDR4.  MC can set DRAM CAL 
  mode after training.
- Enhanced PhyInit Step I to kick off calibration engine after training, no longer
  requiring manual trigger by MC.
- Added fPIC compile option.
- Added function dwc_ddrphy_phyinit_setStruct. see PhyInit documentation for details.
- LPPDDR4: messageBlock DRAM MR defaults changed to be inline with JEDEC defaults 
  for MR3.PuCal and MR22.  See dwc_ddrphy_phyinit_setDefault() for details.
- LPDDR4: fixed message block MR22 bit shifting calculation in setDefault.c
- Applied fix for STAR 9001264921

Minimum Required Versions
-------------------------
- Firmware: A-2017.05
- PUB: 1.00a

------------------------------------------------------------------
Version A-2017.09 
September 1, 2017

Changes from version A-2017.07
(recommended)

Special Notes
-----------

  
Enhancements
-----------
- Added Retention Save and Restore sequence feature.  Please see App Note for
  details.
- Improved source code documentation.
- Added data structure to better control runtime parameters (runtime_config).
- Converted warning message to fatal assertion when invalid PhyDrvIImpedance
  are programmed.
- Includes following Stars: 9001233386, 9001231207, 9001233389, 9001235681

Minimum Required Versions
-------------------------
- Firmware: A-2017.05
- PUB: 1.00a

------------------------------------------------------------------

Version A-2017.07 
July 7, 2017

Changes from version A-2017.05
(recommended)

Special Notes
-----------
- userInputBasic.ReadDBIEnable no longer have any effect on register
  programming   the user input remains in the struct to maintain backward
  compatibility
  
Enhancements
-----------
- Corrected Format for DWC_DDRPHY_PHYINIT_RID
- minor PIE optimization to improve tinit_complete. 
- Added support for impedance programing across Hard Macro Families via
  PhyInit. Updated default message block programing to disable Training
  Firmware programing of PHY impedance values.
- DDR4,LPDDR4: program DMIPinPresent directly from message block MR value to 
  consolidate programing.  userInputBasic.ReadDBIEnable no longer used.
- Seq0BDly programing moved to dwc_ddrphy_phyinit_I_LoadPieImage() to group
  with other PIE registers.
- GlobalVrefInDAC programed from MessageBlock.PhyVref to match VREF programed
  by training firmware.
- LPDDR4 : Updated PIE programming to change TrainingParam when
  userInputAdvanced.DisableRetraining=1 direct

Minimum Required Versions
-------------------------
- Firmware: A-2017.05
- PUB: 1.00a

------------------------------------------------------------------
Version A-2017.05 
May 22, 2017

Changes from version 2.00a
(mandatory)

Special Notes
-----------
- Added new user inputs for LPDDR3 and LPDDR4:
  * userInputAdvanced.DisableRetraining
  * userInputAdvanced.DisablePhyUpdate
  see dwc_ddrphy_phyinit_struct.h for description

- userInputBasic.DfiMode no longer have any effect on register programming
  the user input remains in the struct to maintain backward compatibility

Enhancements
-----------
- Updated dwc_ddrphy_phyinit_progCsrSkipTrain() to be compatible with 
  Hard-macro E (HME)

- Moved assertion of BP_MEMRESET_L from dwc_ddrphy_phyinit_C_initPhyConfig()
  to dwc_ddrphy_phyinit_D_loadIMEM() to prevent memory reset during 
  LP3/IO Retention Exit

Bug Fixes
---------
- Fixed incorrect setting of userInputBasic.Lp4xMode in LPDDR4's dwc_ddrphy_phyinit_setDefault()

Minimum Required Versions
-------------------------
- Firmware: A-2017.05
- PUB: 1.00a

------------------------------------------------------------------

Version 2.00a 
Mar 31, 2017

Enhancements
-----------
 - Major upgrade to improve usability.
 - Added capability to execute training firmware.
 - Added automatic MessageBlock and MR programing based on PhyInit inputs.
 - added user customPre and customPost functions as access points during 
   initialization sequence for custom register programing.
 - capability to read the incv files from a firmware package auto populate
   the message block and generate apb writes for the final SRAM image 
   including IMEM, DMEM from the firmware package.
 - added capability for 4 types of initialization sequence. Refer to PhyInit
   Application Note for details:
    1. SkipTraining
    2. SkipTraining + DevInit
    3. Full 1D training
    4. Full 1D and 2D training

Special Notes
-------------
 - This release places a fixed coded "//" in the output text file for comments
   in addition to the comment string specified to phyinit

Minimum Required Versions
-------------------------
- Firmware: 1.00a
- PUB: 1.00a

-----------------------------------------------------------------
Version 1.23a
Feb 27, 2017

Changes from version 1.22a
(mandatory)

Special Notes
-------------
For simulation without firmware execution, phyinit supports SKIP_TRAIN=1. 
 - Refer to README and documentation for usage.
 - Running phyinit with SKIP_TRAIN=1 is the only supported mode for phyinit in
   this release.
To run firmware based training, please follow the guidance below and refer to
the PUB Databook:
 - Run phyinit steps A, B & C as referenced in dwc_ddrphy_phyinit_sequence.c
   with skip_training==1 (SKIP_TRAIN=1)
 - Follow steps D, E, F, G, H in the PUB Databook. This provides details
   on 1D and 2D training firmware execution.
 - Run phyinit steps I & J as referenced in
   dwc_ddrphy_phyinit_sequence.c with skip_training==0
This PHYINIT utility is not considered final and updates are to be expected.

Additional Special Notes
------------------------
- User should consult PHY Documentation (HSpice Model Application Note) for
  recommended ATxSlewRate and TxSlewRate settings for specific technologies

Bug Fixes
---------
- None

Enhancements
------------
- Add initialization of TxSlewRate and ATxSlewRate controls to provide
  compatibility across a wider family of hard IP block revisions.
- Change default setting of DFIMRL_margin when skipping training to match what
  training would normally do.
- Match dfi_clk_disable behavior during power/clock transitions to behavior
  from 1.21a and before.

Minimum Required Versions
-------------------------
- Firmware: 0.73a
- PUB: 1.00a

------------------------------------------------------------------

Version 1.22a
Jan 26, 2017

Changes from version 1.21a
(mandatory)

Special Notes
-------------
For simulation without firmware execution, phyinit supports SKIP_TRAIN=1. 
 - Refer to README and documentation for usage.
 - Running phyinit with SKIP_TRAIN=1 is the only supported mode for phyinit in
   this release.
To run firmware based training, please follow the guidance below and refer to
the PUB Databook:
 - Run phyinit steps A, B & C as referenced in dwc_ddrphy_phyinit_sequence.c
   with skip_training==1 (SKIP_TRAIN=1)
 - Follow steps D, E, F, G, H in the PUB Databook. This provides details
   on 1D and 2D training firmware execution.
 - Run phyinit steps I & J as referenced in
   dwc_ddrphy_phyinit_sequence.c with skip_training==0
This PHYINIT utility is not considered final and updates are to be expected.

Additional Special Notes
------------------------
- User should consult PHY Documentation (HSpice Model Application Note) for
  recommended ATxSlewRate and TxSlewRate settings for specific technologies

Bug Fixes
---------
- Dynamic Drift compensation sequence update to meet tMRD requirement
- dfi_init_start sequence updated for LPDDR3 to issue MR commands on all
  pstate transitions and to issue REFAB before DRAM is put into self-refresh
- Corrected GlobalVrefInDAC setting for DDR4, LPDDR4, LPDDR3
- Fixed issue in transition from 1D to 2D training - corrected state of
  MicroContMuxSel after 1D training done
- Address STAR: 9001136857

Enhancements
------------
- Add ability to set Firmware message block field DisabledDbyte.  See Firmware
  release notes for use and support.
- Add ability to set Firmware message block PhyConfigOverride.  See Firmware
  release notes for use and support.
- Limit 2D Firmware Message Block to only pstate 0 version; pstate 1..3 were
  not used and are removed from the phyinit C structure.
- Assert BP_MEMRESET_L at the beginning of Phyinit sequence, de-assert by
  firmware or in SKIP_TRAIN=1 case by dwc_ddrphy_phyinit_progCsrSkipTrain()
  - This matches expected BP_MEMRESET_L assertion required in PUB Databook.
    If customer is asserting already, this will be a not cause any further
    transition.
- dfi_phymstr sequence updated to shorten handshake time
- QuickBoot Firmware feature added for LPDDR4 - new
  userInputAdvanced.Lp4Quickboot added to phyinit code to support setting.
- Convert dwc_ddrphy_phyinit_setDefault() and dwc_ddrphy_phyinit_sequence() to
  be of type 'int' instead of type 'void' to improve compilation
  compatibility.

Minimum Required Versions
-------------------------
- Firmware: 0.72a
- PUB: 1.00a

------------------------------------------------------------------

Version 1.21a
Nov 28, 2016

Changes from version 1.20a
(mandatory)

Special Notes
-------------
For simulation without firmware execution, phyinit supports SKIP_TRAIN=1. 
 - Refer to README and documentation for usage.
 - Running phyinit with SKIP_TRAIN=1 is the only supported mode for phyinit in
   this release.
To run firmware based training, please follow the guidance below and refer to
the PUB Databook:
 - Run phyinit steps A, B & C as referenced in dwc_ddrphy_phyinit_sequence.c
   with skip_training==1 (SKIP_TRAIN=1)
 - Follow steps D, E, F, G, H in the PUB Databook. This provides details
   on 1D and 2D training firmware execution.
 - Run phyinit steps I & J as referenced in
   dwc_ddrphy_phyinit_sequence.c with skip_training==0
This PHYINIT utility is not considered final and updates are to be expected.

Bug Fixes
---------
- LPDDR3: receiver major mode setting updated.
- LPDDR4: For CAS-2 command, all address bits are now driven low as per JEDEC.
- LPDDR4: Fixed tMRD violation during PIE sequence.

Enhancements
------------
- Add register names in LoadPieProdCode.c to make lookup and comparison
  easier.
- Improve support for uMCTL2 interop testbench.
- Update PLL power-down duration to ensure stability during back-to-back
  low-power entry/exit.
  
Minimum Required Versions
-------------------------
- Firmware: 0.71a
- PUB: 1.00a

------------------------------------------------------------------

Version 1.20b
Oct 19, 2016

Changes from version 1.20a
(recommended)

Special Notes
-------------
For simulation without firmware execution, phyinit supports SKIP_TRAIN=1. 
 - Refer to README and documentation for usage.
 - Running phyinit with SKIP_TRAIN=1 is the only supported mode for phyinit in
   this release.
To run firmware based training, please follow the guidance below and refer to
the PUB Databook:
 - Run phyinit steps A, B & C as referenced in dwc_ddrphy_phyinit_sequence.c
   with skip_training==1 (SKIP_TRAIN=1)
 - Follow steps D, E, F, G, H in the PUB Databook. This provides details
   on 1D and 2D training firmware execution.
 - Run phyinit steps I & J as referenced in
   dwc_ddrphy_phyinit_sequence.c with skip_training==0

Bug Fixes
---------
- None

Enhancements
------------
- Clarify README direction: 'make' command option
  FIRMWARE_PATH=<path/to/firmware> is not optional.  Update the default path
  in Makefile and in README to make this clearer.
  
Minimum Required Versions
-------------------------
- Firmware: 0.70a
- PUB: 1.00a

------------------------------------------------------------------

Version 1.20a 
Sep 16, 2016

Changes from version 1.11a
(mandatory)

Special Notes
-------------
For simulation without firmware execution, phyinit supports SKIP_TRAIN=1. 
 - Refer to README and documentation for usage.
 - Running phyinit with SKIP_TRAIN=1 is the only supported mode for phyinit in
   this release.
To run firmware based training, please follow the guidance below and refer to
the PUB Databook:
 - Run phyinit steps A, B & C as referenced in dwc_ddrphy_phyinit_sequence.c
   with skip_training==1 (SKIP_TRAIN=1)
 - Follow steps D, E, F, G, H in the PUB Databook. This provides details
   on 1D and 2D training firmware execution.
 - Run phyinit steps I & J as referenced in
   dwc_ddrphy_phyinit_sequence.c with skip_training==0

Bug Fixes
---------
- STAR 9001089067: PHYINIT configuration of Firmware Message Block DRAMFreq
                   Field
- Fix Dynamic Drift Compensation code for certain corner cases in LPDDR4

Enhancements
------------
- Remove DWC_DDRPHY_PHYINIT_FOR_CUST define; default behavior is
  customer-ready without needing to set the define.
- Update firmware load section.
- General coding improvements.
  
Minimum Required Versions
-------------------------
- Firmware: 0.70a
- PUB: 1.00a

------------------------------------------------------------------

Version 1.11a 
Aug 15, 2016

Changes from version 1.10a
(recommended)

Bug Fixes
---------
- Addressed issue for LPDDR3 DDC for RxEnb training using incorrect search parameters.
- Addressed issue with PLL calibration on LP3 entry after training.

Enhancements
------------
- Further improvements / clarifications to the PhyInit process.
  
Minimum Required Versions
-------------------------
- Firmware: 0.50a
- PUB: 1.00a

------------------------------------------------------------------

Version 1.10a 
Jul 22, 2016

Changes from version 1.03a
(recommended)

Bug Fixes
---------
- Improvements to HwtLpCsEnB programming sequence.
- Improvements to Seq0BDLY3 programming sequence.
- Limit CalUclkTicksPer1uS to minimum of 24.

Enhancements
------------
- Improved 2D training support. Phyinit will load and execute 1D and 2D firmware
  images in sequence.
- Performance enhancement to disable DBYTE4 and above if DFI1 does not exist in
  LPDDR3 and LPDDR4.

Minimum Required Versions
-------------------------
- Firmware: 0.50a
- PUB: 1.00a

------------------------------------------------------------------

Version 1.03a 
Jul 11, 2016

Changes from version 1.01a
(recommended)

Bug Fixes
---------
- Updates toward customer enablement
- Makefile cleanup of auto-detect protocol and settings.

Enhancements
------------
- No change

Known Issues
------------
- In LPDDR4, the PHY does not send ZQCAL commands to LPDDR4 DRAMs during
  initialization and frequency change.

Minimum Required Versions
-------------------------
- Firmware: 0.50a
- PUB: 1.00a

------------------------------------------------------------------

Version 1.01a 
Jun 20, 2016

Changes from version 1.00a
(recommended)

Bug Fixes
---------
- Updates toward customer enablement
- Improved initialization code for LPDDR3 and LPDDR4 protocols.

Enhancements
------------
- Automated the 'make' protocol determination by reading post-customer-edited
  files (see README).

Minimum Required Versions
-------------------------
- Firmware: 0.50a
- PUB: 1.00a

------------------------------------------------------------------

Version 1.00a 
Apr 15, 2016

Changes from version 0.10a
(mandatory)

- Updates toward customer enablement.

------------------------------------------------------------------

Version 0.10a 
Mar 21, 2016

Initial release as separate component
(recommended)

- Simplified PHY programming sequence for bring-up. Please see
  initialization_quickstart.txt for details.

------------------------------------------------------------------


Special notes
-------------




